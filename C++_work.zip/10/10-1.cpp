#include<iostream>
using namespace std;

//木头类
class Wood{
public:
    int wamount;
    Wood(int temp) : wamount(temp) { UseWood(); };
    void UseWood() { cout << "The furiniture uses " << wamount << " pieces woods" << endl; };
};

//金属类
class Metal{
public:
    int mamount;
    Metal(int temp) : mamount(temp) { UseMetal(); };
    void UseMetal() {  cout << "The furiniture uses " << mamount << " pieces metals" << endl;};
};

//家具类
class Furniture:public Wood,public Metal{
public:
    Furniture(int a,int b):Wood(a),Metal(b){};      //仅用于传递基类初始化所需的数据
};

//沙发类
class Sofa:public Furniture{
public:
    int sofaweight;
    int sofacapacity;
    Sofa(int a, int b, int c, int d) : Furniture(a, b), sofaweight(d), sofacapacity(c) { CanSit(); };
    void CanSit() {
        cout << "The sofa weights " << sofaweight << " and can sit " << sofacapacity << " persons" << endl;
    }; //用于输出一个沙发具有的质量和可以坐下的人数
};

//床类
class Bed:public Furniture{
public:
    int bedweight;
    int bedcapacity;
    Bed(int e, int f, int g, int h) : Furniture(e, f), bedweight(h), bedcapacity(g) { CanLie(); };
    void CanLie() { cout <<"The bed weights "<< bedweight <<" and can lie "<< bedcapacity<<" persons"<<endl; 
    };//用于输出一个床具有的重量（bedweight）和可以躺下的人数（bedcapacity）;
};

//沙发床合类
class SofaBed:public Sofa,public Bed{
public:
    SofaBed(int a, int b, int c, int d, int e,int f, int g, int h) : Sofa(a, b, c, d), Bed(e, f, g, h) { ItsFunction(); };
    void ItsFunction(){
        cout << "The SofaBed uses " << Sofa::wamount + Bed::wamount << " pieces woods and " 
        << Sofa::mamount + Bed::mamount << " pieces mentals,and weights " 
        << sofaweight + bedweight << " and can accommodate " 
        << sofacapacity + bedcapacity << " persons" << endl;
    };
    //用于输出一个沙发床具有的重量（来自于Sofa和Bed两个类的重量之和）和可以容纳的人数（来自于Sofa和Bed两个类的容量之和）；
};

int main(){
    SofaBed test(40, 20, 4, 100, 60, 30, 2, 150);           //创建沙发床合类对象
    return 0;
}