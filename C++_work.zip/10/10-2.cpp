#include<iostream>
#include<Windows.h>
using namespace std;

//日期类
class Date{
    int Year, Month, Day;
public:
    Date(int y, int m, int d) : Year(y), Month(m), Day(d){};
    void SetDate(int y, int m, int d) { 
        Year = y;
        Month = m;
        Day = d;
    };                      //设置
    void ShowDate(){
        cout << Year << "-" << Month << "-" << Day;
    };                      //显示
};

//时间类
class Time{
    int hour,minute,second;
public:
    Time(int h=0, int m=0, int s=0) : hour(h), minute(m), second(s){};
    void SetTime(int h, int m, int s){
        hour = h;
        minute=m;
        second = s;
    };                      //设置
    void ShowTime(){
        cout << hour << ":" << minute << ":" << second << endl;
    };                      //显示
};

//日期时间继承类（继承方式不影响程序执行，因为继承方式只改变基类在外面的访问权限，不影响派生类对数据的访问）
class DateTime:protected Date,private Time{
public:
    DateTime(int y = 0, int mon = 0, int d = 0, int h = 0, int min = 0, int s = 0):Date(y,mon,d),Time(h,min,s) { ShowDateTime(); };
    void SetDateTime(int y,int mon,int d,int h,int min,int s){
        SetDate(y,mon,d);
        SetTime(h,min,s);
    };                      //设置
    void ShowDateTime(){
        ShowDate();
        cout <<"  ";
        ShowTime();
    };                      //展示
};

int main(){
    SYSTEMTIME sys;
    GetLocalTime(&sys);
    DateTime dt(sys.wYear,sys.wMonth,sys.wHour,sys.wMinute,sys.wSecond);
    char flag='y';
    cout << "是否需要修改日期和时间？（Y/N）";
    cin >> flag;
    while(tolower(flag)=='y'){
        cout << "请输入新的日期和时间:";
        int y,mon,d,h,min,s;
        cin >> y >> mon >> d >> h >> min >> s;
        dt.SetDateTime(y, mon, d, h, min, s);
        cout << "修改后的日期和时间为:";
        dt.ShowDateTime();
        cout << "---------------------" << endl;
        cout << "是否继续修改日期和时间？（Y/N）";
        cin >> flag;
    }
    return 0;
}