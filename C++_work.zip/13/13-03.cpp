#include<iostream>
#include<cmath>
using namespace std;

/**question
 * 前自增和后自增不一样，后自增需要创建临时对象，然后在自增，返回的是临时对象
 * cannot bind non-const lvalue reference of type XXX to an rvalue of type XXX
 * 示例：C=C*A/B;   C*A创建的是一个临时变量
 * 解决办法：/前面一个参数加上const将其变为常量
 * 如果一个参数是以非const引用传入，c++编译器就有理由认为程序员会在函数中修改这个值，
 * 并且这个被修改的引用在函数返回后要发挥作用。但如果你把一个临时变量当作非const引用参数传进来，
 * 由于临时变量的特殊性，程序员并不能操作临时变量，而且临时变量随时可能被释放掉，
 * 所以，一般说来，修改一个临时变量是毫无意义的，
 * 据此，c++编译器加入了临时变量不能作为非const引用的这个语义限制。
 * 
*/

/**Description
 * function    : 有理数运算
 * Author      : LIU
 * Date        : Dec 12, 2020
*/

//Why?  辗转相除法求最大公约数  
int gcd(int nu,int de){
    if(nu==0)
        return 1;       //Why?分子为0，直接返回1，即对分式上下进行化简1
    if(nu<0)
        nu = -nu;
    if(de<0)
        de = -de;       //绝对值
    if(de==0)           //截止条件：余数为0
        return nu;
    return gcd((de>nu?nu:de), de % nu);    //继续，较小的数，余数
}

class Rational
{
    int nume,demo;   //分子和分母
  public:
    Rational(int nu=1, int de=1){
        if(de==0){ 
            cout << "分母为0，输入错误" << endl;
            exit(0);
        };
        int g = gcd(nu, de);
        if(de<0)
            g = -g;     //Why?  把负号变到分子上
        nume = nu / g;
        demo = de / g;
    };      

    void print(){
        cout << "The value is ";
        if(nume==0)
            cout << nume << endl;
        else
            cout << nume << '/' << demo << endl;
    };

//   void sidemople();
    Rational  operator  +(Rational & a);                           //加法
    friend  Rational  operator  -(Rational & a, Rational & b);     //减法
    friend  Rational  operator  *(Rational & a, Rational & b);     //乘法
    friend  Rational  operator  /(const Rational & a, Rational & b);      //除法
    Rational  operator  -();                //取反
    Rational &  operator  ++();            //r=++r1
    Rational  operator  ++(int);            //r=r1++
    Rational &  operator  --();              //r=--r1
    Rational  operator  --(int);             //r =r1--
    void Sym_adjust();                       //Why?      调整正负号，让负号在分子
    //    operator  double();
    //    friend ostreademo& operator<<(ostreademo& output, Rational& a);
    //    bool operator  <(Rational &);
    //    friend bool operator  ==(Rational&, Rational&);
};

//Function:调整正负号，让负号在分子
void Rational::Sym_adjust(){
    int g = 1;
    if(demo<0)
        g = -1;
    nume = nume / g;
    demo = demo / g;
}

Rational Rational::operator+(Rational& a){
    Rational temp;
    //化为同分母，再进行运算
    temp.demo = this->demo * a.demo;
    temp.nume = this->nume*a.demo + a.nume*this->demo;        

    //求最大公约数并化简分式
    int g = gcd(temp.nume, temp.demo);                        
    temp.demo = temp.demo / g;
    temp.nume = temp.nume / g;              
    return temp;
}

Rational operator-(Rational& a,Rational& b){
    Rational temp;
    //化为同分母，再进行运算
    temp.demo = a.demo * b.demo;
    temp.nume = a.nume - b.nume;        

    //求最大公约数并化简分式
    int g = gcd(temp.nume, temp.demo);      
    temp.demo = temp.demo / g;
    temp.nume = temp.nume / g;              
    return temp;
}

Rational operator*(Rational& a,Rational& b){
    Rational temp;
    //化为同分母，再进行运算
    temp.demo = a.demo * b.demo;
    temp.nume = a.nume * b.nume;        

    //求最大公约数并化简分式
    int g = gcd(temp.nume, temp.demo);      
    temp.demo = temp.demo / g;
    temp.nume = temp.nume / g;              
    temp.Sym_adjust();
    return temp;
}

Rational operator/(const Rational& a,Rational& b){
    Rational temp;
    //化为同分母，再进行运算
    temp.demo = a.demo * b.nume;
    temp.nume = a.nume * b.demo;        

    //求最大公约数并化简分式
    int g = gcd(temp.nume, temp.demo);      
    temp.demo = temp.demo / g;
    temp.nume = temp.nume / g;              
    temp.Sym_adjust();
    return temp;
}

Rational Rational::operator -(){
    Rational temp;
    temp.nume = -this->nume;
    temp.demo = this->demo;
    temp.Sym_adjust();
    return temp;
}

Rational& Rational::operator  ++(){
    nume += demo;
    return *this;
}

Rational  Rational::operator  ++(int){
    Rational temp = *this;
    nume += demo;
    return temp;
}

Rational& Rational::operator  --(){
    nume -= demo;
    return *this;
}

Rational Rational::operator  --(int){
    Rational temp=*this;
    nume -= demo;
    return temp;
}

int main(){
	Rational  A(2,6),  B(1,-2),  C;
    C=-A;     C.print( );           //输出1/3
	C=A+B;    C.print( );           //输出-1/6
	C=C*A/B;  C.print( );
	C=++A;    A.print( );    C.print( );
	C=B--;    B.print( );    C.print( );
    return 0;
}
