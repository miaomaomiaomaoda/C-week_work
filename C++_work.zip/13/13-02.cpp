#include <iostream>
using namespace std;

/**Description
 * function    : 实现矩阵的运算符重载
 * Author      : LIU
 * Date        : Dec 11, 2020
*/

class Matrix      //定义Matrix类
{
    int mat[50][50];
  public:
    static int m, n;
    Matrix(){};                    //默认构造函数
    friend Matrix operator +(Matrix &, Matrix &);    //重载运算符"+"
    friend Matrix operator -(Matrix &, Matrix &);    //-
    friend Matrix operator *(Matrix &, Matrix &);    //*
    friend Matrix operator /(Matrix &, Matrix &);    // /
    void input(); //输入数据函数
    void display(); //输出数据函数
};


int Matrix::m = 0;
int Matrix::n = 0;

void Matrix::input(){
  cout << "Input the value of the Matrix:";
  for(int i=0;i<m;i++){
    for (int j = 0; j < n;j++){
      cin >> mat[i][j];
    }
  }
};

void Matrix::display(){
  for(int i=0;i<m;i++){
    for (int j = 0; j < n;j++){
      cout.width(3);
      cout << mat[i][j];
      if(j==1)
        cout << endl;
    }
  }
};

Matrix operator + (Matrix& op1,Matrix& op2){
  Matrix op3;
  for (int i = 0; i < op1.m;i++){
      for (int j = 0;j<op1.m;j++){
        op3.mat[i][j]=op1.mat[i][j]+op2.mat[i][j];
    }
  }
  return op3;
};

Matrix operator - (Matrix& op1,Matrix& op2){
  Matrix op3;
  for (int i = 0; i < op1.m;i++){
    for (int j = 0;j<op1.m;j++){
        op3.mat[i][j]=op1.mat[i][j]-op2.mat[i][j];
    }
  }
  return op3;
};

Matrix operator * (Matrix& op1,Matrix& op2){
  Matrix op3;
  for (int i = 0; i < op1.m;i++){
    for (int j = 0;j<op1.m;j++){
        op3.mat[i][j]=op1.mat[i][j]*op2.mat[i][j];
    }
  }
  return op3;
};

Matrix operator / (Matrix& op1,Matrix& op2){
  Matrix op3;
  for (int i = 0; i < op1.m;i++){
    for (int j = 0;j<op1.m;j++){
        op3.mat[i][j]=op1.mat[i][j]/op2.mat[i][j];
    }
  }
  return op3;
};

int main()
{
  cout<<"Please input two dimensions of the matrix:  ";
  cin >> Matrix::m >>Matrix::n;
  Matrix a, b, c;
  a.input();      b.input();  
  cout<<endl<<"Matrix a:"<<endl;    a.display();
  cout<<endl<<"Matrix b:"<<endl;    b.display();
  
  c=a+b;                    //用重载运算符"+"实现两个矩阵相加
  cout<<endl<<"Matrix c = Matrix a + Matrix b :"<<endl;  c.display();
  c=a-b;                     //用重载运算符"+"实现两个矩阵相加
  cout<<endl<<"Matrix c = Matrix a - Matrix b :"<<endl;  c.display();
  c=a*b;                     //用重载运算符"+"实现两个矩阵相加
  cout<<endl<<"Matrix c = Matrix a * Matrix b :"<<endl;  c.display();
  c=a/b;                      //用重载运算符"+"实现两个矩阵相加
  cout<<endl<<"Matrix c = Matrix a / Matrix b :"<<endl;  c.display();
  return 0;
}
