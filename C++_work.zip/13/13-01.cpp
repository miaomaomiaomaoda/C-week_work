#include<iostream>
#include<string>
#include<cstring>
using namespace std;

/**Description
 * function    : 多种运算符重载
 * Author      : LIU
 * Date        : Dec 11, 2020
*/

class Oper{
int data;
char str[200];

public:
    Oper(int num, char strn[200]) : data(num) { strcpy(str, strn); };
    Oper(){};
	Oper& operator + (Oper&);
	Oper& operator -	(Oper&);
    //重载前置运算符,无需参数
	Oper operator ++();		
	Oper operator --();
    
    //重载后置运算符，设立哑元int（有类型无名称），用于向编译器说明这是后置的重载
    Oper operator ++(int);		
	Oper operator --(int);

    void operator = (Oper);
    void operator ! ();         //Why?  数据取反
    int operator [](Oper&);     //Why?  数据匹配,示例a[b],判断b字符串是被a包含
    int show(){
        return data;
    };
    int getdata() { return data; };
};

Oper& Oper::operator + (Oper& op){
	data=data+op.data;
	return *this;
}

Oper& Oper::operator - (Oper& op){
	data=data-op.data;
	return *this;
}

Oper Oper::operator ++(){
	++this->data;
}

Oper Oper::operator --(){
	--this->data;
}

Oper Oper::operator ++(int){
    Oper temp = *this;
    ++this->data;
    return temp;
}

Oper Oper::operator --(int){
    Oper temp = *this;
	--this->data;
    return temp;
}

void Oper::operator =(Oper op){
    data = op.getdata();
}

void Oper::operator!(){
    data = 0 - data;
}

int Oper::operator[](Oper& op){
    const char* p;
    const char* a = str;
    const char* b = op.str;
    p = strstr(a,b);
    if(p!=NULL)
        return 1;
    else
        return 0;
}

//Why?  展示当前各个对象内数据data状态
void showall(Oper d1,Oper d2,Oper d3,Oper d4,Oper d5){
    cout << endl<<endl;
    cout << "The current state: " << endl
         << "d1= " << d1.show()
         << "    d2= " << d2.show()
         << "    d3= " << d3.show()
         << "    d4= " << d4.show()
         << "    d5= " << d5.show() << endl;
}

int main(){
	Oper d1(12,"hello"),d2(25,"world"),d3(45,"my"),d4(0,"program"),d5(0,"prv");
    showall(d1,d2,d3,d4,d5);

    d3=d1+d2;
	cout<<"outcome d3=d1+d2="<<d3.show();          //+

    showall(d1,d2,d3,d4,d5);
    d3 = d2 - d1;
    cout<<"outcome d3=d2-d1="<<d3.show();          //-

    showall(d1,d2,d3,d4,d5);
    d4=d1+d2+d3;
	cout<<"outcome d4=d1+d2+d3="<<d4.show();      //连+

    showall(d1,d2,d3,d4,d5);
    d4++;
	cout<<"outcome d4++="<<d4.show();      //++后置

    showall(d1,d2,d3,d4,d5);
    ++d4;
	cout<<"outcome ++d4="<<d4.show();      //++前置

    showall(d1,d2,d3,d4,d5);
    d4--;
	cout<<"outcome d4--="<<d4.show();      //--后置

    showall(d1,d2,d3,d4,d5);
    --d4;
	cout<<"outcome --d4="<<d4.show();      //--前置

    showall(d1,d2,d3,d4,d5);
    d5=d3+d4;
    cout<<"outcome d5=d3+d4="<<d5.show();  //=

    showall(d1,d2,d3,d4,d5);
    !d5;
    cout<<"outcome !d5="<<d5.show();       //!

    showall(d1,d2,d3,d4,d5);
    cout<<d4[d5]<<endl<<endl;              //[]

    Oper *d6 =&d5;
    cout << "d5= " << d5.getdata() << endl;
    cout << d6->getdata()<<endl;           //->
    return 0;
}

//存在问题：未事先想好重构运算符的作用，导致对类数据的不断增加，以实现各种功能