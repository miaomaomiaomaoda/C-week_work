#include<iostream>
using namespace std;

class Singer{
	char name[20];		//姓名	
	char gender[10];	//性别
	int age;			//年龄
	char song[30];		//演唱曲目
public:
	Singer();			//构造函数
	Singer(int x);		//带参数的构造函数
	~Singer();			//析构函数
	void Enroll();		//报名
	void Display();		//显示
	void Modify();		//修改

};

//不带参构造函数
Singer::Singer()		
{
	cout<<"调用Singer构造函数!"<<endl;
}

//带参数的构造函数
Singer::Singer(int x)	
{
	cout<<"请输入歌手的信息（姓名、性别、年龄、演唱曲目）:";
	cin>>name>>gender>>age>>song;
}

//析构函数
Singer::~Singer()
{
	cout<<"调用Singer析构函数!"<<endl;
}

//报名函数
void Singer::Enroll()	
{
	cout<<"请输入歌手的信息（姓名、性别、年龄、演唱曲目）:";
	cin>>name>>gender>>age>>song;
}

//歌手信息显示函数
void Singer::Display()		//显示
{
	cout<<name<<" "<<gender<<" "<<age<<" "<<song<<endl;
}

//歌手信息修改函数
void Singer::Modify()		
{
	int N;
	cout<<"1.姓名	2.性别	3.年龄	4.演唱曲目"<<endl;
	cout<<"请选择需要修改的歌手信息序号:";
	cin>>N;
	switch(N)
	{
		case 1:cout<<"请输入新的姓名:";cin>>name;break;
		case 2:cout<<"请输入新的性别:";cin>>gender;break;
		case 3:cout<<"请输入新的年龄:";cin>>age;break;
		case 4:cout<<"请输入新的演唱曲目:";cin>>song;break;
	}
	cout<<"歌手信息修改成功!"<<endl;
}
				
int main()
{
	int N=0;				
	int i;
	int num=0;				//当前Manage表内歌手信息数，
	char function;			//判断标志符
	Singer Manage[20];		//歌手情况表，共能容纳10名歌手信息
	Singer* p;
	cout<<"*******************************************"<<endl;
	
	//构造函数初始化歌手信息
	cout<<"请输入这次报名歌手的数量(<=10):";
	cin>>N;
	for(i=num;i<N+num;i++)
	{
		p=new Singer(1);
		Manage[i]=*p;
	}
	num=num+N;				//更新歌手信息数

	while(1)
	{
		//歌手信息表输出
		cout<<"报名歌手的信息如下所示:"<<endl;
		for(i=0;i<num;i++)
		{
			Manage[i].Display();
		}

		//修改信息
		cout<<"是否需要修改报名歌手的信息(Y/N):";
		cin>>function;
		if(function=='Y'||function=='y')
		{
			cout<<"请输入需要修改的歌手信息序号:";
			cin>>N;
			if(N>num)
				cout<<"输入错误,无此序号选手"<<endl;
			else
			{
				Manage[N-1].Modify();
				cout<<"修改后的歌手信息如下所示:"<<endl;
				Manage[N-1].Display();
			}
		}

		//继续输入判断
		cout<<"是否继续输入报名歌手的信息?(Y/N)";
		cin>>function;
		if(function=='N'||function=='n')
			break;


		//歌手信息输入
		cout<<"请输入报名歌手的数量:";
		cin>>N;
		for(i=num;i<num+N;i++)
			Manage[i].Enroll();
		num=N+num;				//更新歌手信息数
	}
	free(p);					//释放动态分配空间
	//调用析构函数
	for(i=0;i<num;i++)			
		Manage[i].~Singer();
	return 1;
}
