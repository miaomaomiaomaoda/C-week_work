#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
//修改：求平方根用//符号表示？
class calculator
{
	private:
		double op1,op2;		//操作数1,2
		char function;		//运算符
		char point;			//单目运算判断符
	public:
		void add();			//加法函数
		void reduce();		//减法函数
		void mutiply();		//乘法函数
		void division();	//除法函数
		void square();		//平方函数
		void modular();		//求模函数
		void squareroot();	//求平方根函数胡
		void opreation();	//操作函数
};

void calculator::add()
{
	cout<<op1<<'+'<<op2<<'='<<op1+op2<<endl;
	op1=op1+op2;
}
void calculator::reduce()
{
	cout<<op1<<'-'<<op2<<'='<<op1-op2<<endl;
	op1=op1-op2;
}
void calculator::mutiply()
{
	cout<<op1<<'*'<<op2<<'='<<op1*op2<<endl;
	op1=op1*op2;
}
void calculator::division()
{
	cout<<op1<<'/'<<op2<<'='<<op1/op2<<endl;
	op1=op1/op2;
}
void calculator::square()
{
	cout<<op2<<"的二次方:"<<pow(op2,2)<<endl;
}
void calculator::modular()
{
	cout<<op1<<'%'<<op2<<'='<<int(op1)%int(op2)<<endl;
	op1=int(op1)%int(op2);
}
void calculator::squareroot()
{
	cout<<op2<<"平方根为:"<<sqrt(op2)<<endl;
}
void calculator::opreation()
{
	int i=1;					//操作次数
	char point;					//再操作标记
	while(1)
	{
		if(1==i++)				//第一次实现操作数1输入
		{
			cout<<"请输入操作数1: ";
			cin>>op1;
		}	
		else					
		{
			cout<<"是否再进行操作?(Y/N): ";
			cin>>point;
			if(point!='Y'&&point!='y')		
			{
				cout<<"已经退出计算器"<<endl;
				break;
			}
		}
		//单目运算是对新输入的数据单目运算
		cout<<"请输入操作数2: ";
		cin>>op2;
		cout<<"请输入运算符:(平方根用s表示):  ";
		cin>>function;
		switch(function)
		{
			case '+':add();break;
			case '-':reduce();break;
			case '*':mutiply();break;
			case '/':division();break;
			case '2':cout<<"平方根将会作用于新的操作数"<<endl;square();break;
			case '%':modular();break;
			case 's':cout<<"平方根将会作用于新的操作数"<<endl;squareroot();         //修改：求平方根用//符号表示？
		};
		
	}
}

int main()
{
	calculator Cal;			//定义cal类
	Cal.opreation();		//调用操作函数
}


