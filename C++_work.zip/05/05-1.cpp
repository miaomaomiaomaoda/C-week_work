#include<iostream>
#include<iomanip>
using namespace std;

class Matrix
{
	private:
		int line,row;		//行，列
		int *p;
		int num;
		char point;			//询问标志
	public:
		void Matrix_Input();			//输入数据
		void Matrix_Show();				//输出矩阵
		void Matrix_Multiply();			//数乘
		void Matrix_Transpose();		//转置
		void Matrix_Rotate();			//旋转
		void Matrix_Delete();			//清空内存
};

//数据输入，矩阵初始化
void Matrix::Matrix_Input()
{
	int i;
	//行列输入
	cout<<"Please input the dimension of the matrix:";
	cin>>line>>row;
	p=new int[line*row];	//动态分配一个数组存入p指针

	//数组元素输入
	cout<<"Please input the elments of the matixs:"<<endl;
	for(i=0;i<line*row;i++)
		cin>>p[i];
}
//矩阵展示函数
void Matrix::Matrix_Show()
{
	int i;
	//初始矩阵输出
	cout<<"The original matrix is:"<<endl;
	for(i=0;i<line*row;i++)		//矩阵输出
	{
		cout.width(3);
		cout<<p[i]<<' ';
		if(0==((i+1)%row))			//换行
			cout<<endl;
	} 
}
//数乘函数
void Matrix::Matrix_Multiply()
{
	int i=1;				//标记数乘次数
	while(1)
	{
		if(1==i++)
			cout<<"Do you want to multiply the matrix with a number?(Y/N) ";
		else
			cout<<"Do you want to continue mulitiply the matrix?(Y/N) ";
		cin>>point;
		if(point=='Y'||point=='y')
		{
			cout<<"Please input the num:";
			cin>>num;
				//输出矩阵
			cout<<"The matrix mutiplied by a number is:"<<endl;
			for(i=0;i<line*row;i++)		//矩阵输出
			{
				cout.width(3);
				cout<<p[i]*num<<' ';
				if(0==((i+1)%row))		//换行
					cout<<endl;
			}
		}
		else
			break;
	}
}


//矩阵转置函数
void Matrix::Matrix_Transpose()
{
	int i,j;
	//转置输出
	cout<<"Do you want to transpose the matrix?(Y/N) ";
	cin>>point;
	if(point=='Y'||point=='y')
	{
		cout<<"The tansposed matrix is:"<<endl;
		for(i=0;i<row;i++)			//行输出控制
		{
			for(j=i;j<=(i+(line-1)*row);j=j+row)	//列输出控制
			{	
				cout.width(3);		//宽度控制3
				cout<<p[j];
			}
			cout<<endl;
		}
	}
}

//旋转函数
void Matrix::Matrix_Rotate()
{
	int i,j;
	int angle;
	num=1;
	//旋转角度
	while(1)
	{
		if(1==num++)
			cout<<"Do you want to rotate the matrix?(Y/N) ";
		else
			cout<<"Do you want to continue rotate the matrix?(Y/N) ";
		cin>>point;
		if(point=='Y'||point=='y')
		{
			cout<<"Please input the angle you want to ratate(90,180,270): ";
			cin>>angle;
	
			//角度选择
			if(angle==90)
			{
				cout<<"The matrix after ratating 90 is:"<<endl;
				for(i=(line-1)*row;i<line*row;i++)				//行输出控制，输出row行
				{
					for(j=i;j>=(i-(line-1)*row);j=j-row)		//列输出控制，输出line列
					{
						cout.width(3);
						cout<<p[j];
					}
					cout<<endl;
				}
			}
			else if(angle==180)			
			{
				cout<<"The matrix after ratating 180 is:"<<endl;
				for(i=line*row-1;i>=0;i--)						//逆向输出
				{
					cout.width(3);
					cout<<p[i];
					if(i%row==0)								//换行控制
						cout<<endl;
				}
			}
			else if(angle==270)
			{
				cout<<"The matrix after ratating 270 is:"<<endl;
				for(i=row-1;i>=0;i--)							//行输出控制，输出row行
				{
					for(j=i;j<=(i+(line-1)*row);j=j+row)		//列输出控制，输出line列
					{
						cout.width(3);							//宽度控制3
						cout<<p[j];
					}
					cout<<endl;
				}
			}
			else
				cout<<"You inpiut a wrong angle;"<<endl;
		}
		else
			break;
	}
}

//释放动态分配内存
void Matrix::Matrix_Delete()
{
	delete []p;
}

int main()
{
	Matrix matrix;				//定义matrix类
	matrix.Matrix_Input();		//矩阵输入函数	
	matrix.Matrix_Show();		//矩阵输出函数
	matrix.Matrix_Multiply();	//数乘函数
	matrix.Matrix_Transpose();	//转置函数
	matrix.Matrix_Rotate();		//旋转函数
	matrix.Matrix_Delete();		//释放动态空间
	return 1;
}