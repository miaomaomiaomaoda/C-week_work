#include<iostream>
#include<iomanip>
using namespace std;
const int MaxSize=10;
class Array
{
	int length;
	int data[MaxSize];
public:
	Array(int N);		//构造函数初始化数据成员
	int Insert();		//有序插入指定元素
	int Delete();		//删除指定元素X，后面元素前移
	void Display();		//显示所有元素
	void Search();		//查找指定元素X
	void Sort();		//从小到大排序
};

//构造函数初始化数据成员
Array::Array(int N)
{
	length=N;			//数组长度更新
	
	//数组元素输入
	cout<<"请输入数组元素: ";
	for(int i=0;i<N;i++)
		cin>>data[i];
	cout<<"调用构造函数初始化数组成功"<<endl;
	cout<<"************************************************"<<endl;
}

//数组输出函数
void Array::Display()
{
	cout<<"显示数组元素:";
	for(int i=0;i<length;i++)
	{
		cout.width(4);		//宽度控制4
		cout<<data[i];
	}
}

//插入函数
int Array::Insert()
{
	int x;
	int point=0;			//插入位置
	if(length==MaxSize)
	{
		cout<<"数组已满，无法插入!";
		return 0;
	}
	cout<<"请输入需要插入的数字: ";
	cin>>x;

	//寻找插入位
	for(int i=0;i<length-1;i++)
	{
		if(x<data[0])						//插入队头的情况
		{
			point=0;
			break;
		}
		else if(x>data[length-1])			//插入队尾的情况
		{
			point=length;
			break;
		}
		else if((data[i]<=x&&data[i+1]>x)||(data[i]>=x&&data[i+1]<x))
		{
			point=i+1;
			break;
		}
	}
	
	if(point==length)						//插入队尾
		data[length]=x;
	else
	{
		//point及其后面的元素后移一位
		for(i=length;i>=point;i--)	
			data[i+1]=data[i];

		//将元素x插入point
		data[point]=x;
	}
	length++;						//插入一个元素长度++
	return 1;
}

//删除元素
int Array::Delete()		//删除指定元素X，后面元素前移
{
	int x;
	int point=0;		//已删除标记
	int P_delete=0;		//是否删除标志
	int num=0;			//删除指定元素X的个数
	if(length==0)
	{
		cout<<"数组为空，无法删除"<<endl;
		return 0;
	}

	cout<<"请输入要删除的数字: ";
	cin>>x;
	//寻找删除的数
	for(int i=0;i<length;i++)
	{
		if(point==1)			//解决数组内指定元素存在多个时，删除只能删除一个的 问题，point=1表示已删除，
		{
			point=0;			//清零，避免影响后序循环
			i=i-1;				//删除后，重新检查该位置
		}
		if(data[i]==x)
		{
			point=1;			//删除标志更新
			P_delete=1;			//是否删除标志更新
			num++;				//删除的个数
			
			//数据前移
			for(int j=i;j<length;j++)
				data[j]=data[j+1];
		}
	}
	if(P_delete==1)
		length=length-num;
	else
		cout<<"数组内无该元素";
	return 1;

}

void Array::Search()		//查找指定元素X
{
	int x;
	int point=0;				//是否找到标志
	cout<<"请输入要查找的数字: ";
	cin>>x;

	//查找位置
	cout<<"此数字位置是:";
	for(int i=0;i<length;i++)
	{
		if(data[i]==x)
		{
			cout<<i+1<<"  ";
			point=1;
		}
	}

	//不存在的情况输出
	if(point==0)
		cout<<" 无，不存在该元素 ";
}

//从小到大排序
void Array::Sort()
{
	int temp;
	int function;
	cout<<"请输入排序的方式<1-升序；2-降序>  ";
	cin>>function;

	//选择排序
	for(int i=0;i<length-1;i++)
	{
		for(int j=i+1;j<length;j++)
		{
			if((function==1?(data[i]>data[j]):(data[i]<data[j])))
			{
				temp=data[i];
				data[i]=data[j];
				data[j]=temp;
			}
		}	
	}
	cout<<"数组元素排序成功"<<endl;
}



int main()
{
	int point;		//退出标记
	int length;
	Array* p;
	cout<<"输入数组的长度<10>:";
	cin>>length;
	p=new Array(length);

	//数组的操作
	int function;			//功能
	while(1)
	{
		cout<<"************************************************"<<endl;
		cout<<"1.显示	2.排序	3.插入	4.删除	5.查找	6.退出"<<endl;
		cout<<"************************************************"<<endl;
		cout<<"请选择操作项:";
		cin>>function;
		switch(function)
		{
			case 1:p->Display();break;
			case 2:p->Sort();break;
			case 3:p->Insert();break;
			case 4:p->Delete();break;
			case 5:p->Search();break;
			case 6:point=1;break;
		}
		cout<<endl;
		if(point==1)
		{
			point=0;		//归零，不影响下次循环
			break;
		}
	}
	return 1;
}

	
