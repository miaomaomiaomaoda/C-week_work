#include<iostream>
#include "Box.h"
#include<iomanip>
using namespace std;

int main()
{
	//定义BOX1，BOX2，BOX3类，其中BOX1通过输入初始化,BOX2通过拷贝函数初始化为BOX1各项的2倍，BOX通过拷贝函数初始化为BOX1+BOX2
	Box BOX1,BOX2(BOX1,2),BOX3(BOX1,BOX2);		
	cout<<"BOX1:"<<endl;
	BOX1.compute_perimeter();
	BOX1.compute_area();
	BOX1.compute_volume();
	cout<<endl<<"BOX2:"<<endl;
	BOX2.compute_perimeter();
	BOX2.compute_area();
	BOX2.compute_volume();
	cout<<endl<<"BOX3:"<<endl;
	BOX3.compute_perimeter();
	BOX3.compute_area();
	BOX3.compute_volume();
	return 1;
}