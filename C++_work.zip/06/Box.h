#ifndef _Box_h_
#define _Box_h_
#include<iostream>
using namespace std;


class Box{
	double length;
	double width;
	double height;
	
	//成员函数
public:
	void compute_perimeter();
	void compute_area();
	void compute_volume();

	//构造函数
	Box()
	{
		cout<<"Please input the length,width and height of the box: ";
		cin>>length>>width>>height;
		cout<<"BOX1 initialization success!"<<endl;
	}
	//拷贝构造函数
	Box(Box& A,int n)
	{
		length=A.length*n;
		width=A.width*n;
		height=A.height*n;
		cout<<"BOX2 initialization success!"<<endl;
	}
	//拷贝构造函数
	Box(Box& A,Box& B)
	{
		length=A.length+B.length;
		width=A.width+B.width;
		height=A.height+B.height;
		cout<<"BOX3 initialization success!"<<endl;
	}
	Box(double a,double b,double c):length(a),width(b),height(c){cout<<"initialization success!"<<endl;}
};

//成员函数定义
void Box::compute_perimeter()			//周长
{	
	cout<<"The perimeter of the box is: "<<2*(length+width+height)<<endl;	
}
void Box::compute_area()			//表面积
{
	cout<<"The superficial area of the box is: "<<2*(length*width+length*height+width*height)<<endl;
}
void Box::compute_volume()			//体积
{
	cout<<"The volumn of the box is: "<<(length*width*height)<<endl;
}

#endif 