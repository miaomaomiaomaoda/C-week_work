#include<iostream>
using namespace std;

//课程类的定义
class Course
{
	char cno[20];			//课程号
	char cname[20];			//课程名
public:
	void course_show();		//课程输出函数
	void course_set();		//数据输入函数
};

//数据输入函数
void Course::course_set()
{
	cin>>cno>>cname;
}

//课程情况输出函数
void Course::course_show()
{
	cout<<cno<<' '<<cname<<' ';
}

//分数类
class Score
{
	int	score;					//分数
public:
	void score_show();			//分数输出函数
	void score_set();			//分数输入函数
};

//分数输入函数
void Score::score_set()
{
	cin>>score;
}

//成绩情况输出函数
void Score::score_show()
{
	cout<<score<<endl;
}

//学生类
class Student
{
	int sno;			//学号
	char sname[20];		//姓名
	char gender[4];		//性别
	char grade[10];		//班级
	Course scourse;		//课程类
	Score sscore;		//成绩类
	
public:
	Student(){}				//不带参构造函数
	Student(char x);		//带参构造函数
	void student_show();	//学生情况展示函数
	int Get_sno();			//学号获取函数
};

//带参构造函数
Student::Student(char x)
{
	cout<<"Student info:"<<endl;
	cin>>sno>>sname>>gender>>grade;
	scourse.course_set();
	sscore.score_set();
}

//学号获取函数
int Student::Get_sno()
{
	return sno;
}

//学生情况输出函数
void Student::student_show()
{
	cout<<"Student info:"<<endl;
	cout<<sno<<' '<<sname<<' '<<gender<<' '<<grade<<' ';
	scourse.course_show();
	sscore.score_show();
}

int main()
{
	Student Manage[100];				//定义Student类对象Manage[100],可存储总共100条学生信息
	Student* p;							//定义Student类对象指针p，
	int i=0;
	int point=0;						//记录上次插入Manage的位置，判断是否完成查询
	int num;							//学生信息条数
	char f_1,f_2,f_3;					//是否继续标志
	int Sno;							//存放待查询学号

	//学生信息输入
	while(1)
	{
		cout<<"Please enter the Student number you want to input: ";
		cin>>num;
		cout<<"请输入"<<num<<"个课程及其分数信息（2016116101 张山 男 计科161 COST3114 C++ 90）:"<<endl;
		//输入学生信息
		for(i=point;i<num+point;i++)
		{
			p=new Student('y');			//分配空间，并调用构造函数初始化数据
			Manage[i]=*p;				//将学生信息插入Manage数组
		}
		point=num+point;				//记录Manage内插入的学生信息条数，方便下次插入			

		//继续判断
		cout<<"继续输入课程成绩吗?(Y/N)";
		cin>>f_1;
		if(f_1=='N'||f_1=='n')
			break;
	}

	//学生信息查询
	cout<<"请问是否要查询学生信息?(Y/N)";
	cin>>f_2;
	while(f_2=='Y'||f_2=='y')
	{
		//待查询学号是输入
		cout<<"请输入要查询学生的学号:";
		cin>>Sno;

		//查询学生信息
		i=0;
		point=0;
		while(Manage[i].Get_sno())
		{
			if(Sno==Manage[i].Get_sno())
			{
				point=1;						//标记已找到
				cout<<"要查询的学生信息已找到:"<<endl;
				Manage[i].student_show();		//学生信息输出
				break;
			}
			i++;
		}
		if(point==0)				//标记为0未找到输出不存在信息
			cout<<"你要查询的学生信息不存在!"<<endl;
		//继续查询判断
		cout<<"是否继续查询?(Y/N)";
		cin>>f_3;
		if(f_3=='N'||f_3=='n')
			break;
	}
	free(p);						//释放动态空间
	return 1;
}