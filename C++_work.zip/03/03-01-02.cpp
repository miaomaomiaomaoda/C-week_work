#include<iostream>
#include <stdlib.h>
using namespace std;

typedef struct LNode *List;
typedef struct LNode{
	int Data;
	List Next;
}*PtrL;

int line,row;

//链表中查找第K个元素
List FindKth(List PtrL,int K)
{
	List p=PtrL;
	int i=1;
	while(p!=NULL&&i<K)
	{
		p=p->Next;
		i++;
	}
	if(i==K)	return p;		//如果找到第K个元素，返回其指针
	else return NULL;			//否则返回空指针
}


//链表元素插入
List Insert(List PtrL,int X,int i)
{
	List p,s;
	if(i==1)								//数据插入在表头
	{
		s=(List)malloc(sizeof(struct LNode));
		s->Data=X;
		s->Next=PtrL;
		return s;							//返回新表头指针
	}
	p=FindKth(PtrL,i-1);					//查找第（i-1）个结点，并返回指针给p

	if(p==NULL)								//没找到则输出参数错误
	{
		cout<<"参数错误"<<endl;
		return NULL;
	}
	else
	{
		s=(List)malloc(sizeof(struct LNode));
		//插入结点
		s->Data=X;
		s->Next=p->Next;
		p->Next=s;
		return PtrL;
	}
}

//循环输出
void Print(List PtrL)
{
	List p=PtrL;
	int i=0;
	while(p)						//不断输出结点并将结点后移
	{
		cout<<p->Data<<' ';
		p=p->Next;
		i++;
		if(i%row==0)
			cout<<endl;
	}
}

//输入数据，实现数乘，输出
int Oper_Matrix(List PtrL)
{
	int i,num,temp;			//循环变量,数乘数，临时变量
	List p;

	//输入矩阵的行列
	cout<<"Please input the dimension of the matrix:"<<endl;
	cin>>line>>row;

	//输入数组元素
	cout<<"Please input the elements of the matrix:"<<endl;
	for(i=1;i<=(line*row);i++)
	{
		cin>>temp;
		PtrL=Insert(PtrL,temp,i);		//调用insert函数，将元素插入链表末尾
	}

	
	//输出初始方阵
	cout<<"The original matrix is:"<<endl;
	Print(PtrL);						//调用调用Print函数，以矩阵形式输出链表初始元素

	//输入数乘的数据
	cout<<"Please enter the number that will multiply the matrix:";
	cin>>num;
	p=PtrL;
	while(p)							//链表
	{
		p->Data=(p->Data)*num;			//实现数乘操作
		p=p->Next;						//结点向后移动一位
	}
	Print(PtrL);						//调用Print函数，以矩阵形式输出链表所有元素
	return num;
}




int main()
{
	List PtrL=NULL;				//定义头指针
	Oper_Matrix(PtrL);			//调用输入函数
	return 1;
}