#include<iostream>
using namespace std;

int line,row;

//1.输入数据
int InputMatrix(int *matrix)
{
	int i,num;

	//输入矩阵的行列
	cout<<"Please input the dimension of the matrix:"<<endl;
	cin>>line>>row;

	//输入数组元素
	cout<<"Please input the elements of the matrix:"<<endl;
	for(i=0;i<(line*row);i++)
		cin>>matrix[i];
	
	//输出初始方阵
	cout<<"The original matrix is:"<<endl;
	for(i=0;i<(line*row);i++)
	{
		cout<<matrix[i]<<' ';
		if((i+1)%row==0)
			cout<<endl;
	}

	//输入数乘的数据
	cout<<"Please enter the number that will multiply the matrix:";
	cin>>num;
	return num;
}
//2.输出
void OutputMatrix(int *matrix)
{
	int i;
	for(i=0;i<(line*row);i++)						
	{
		cout<<*(matrix+i)<<' ';
		if((i+1)%row==0)						//换行
			cout<<endl;
	}
}

//3.数乘
void MultiplyMatrix(int *matrix, int num)
{
	int i;
	for(i=0;i<(line*row);i++)					//数乘
		*(matrix+i)=*(matrix+i)*num;
}


int main()
{

	int num;						//num存放数乘的数据
	int matrix[100];				//定义一维数组存放数据
	num=InputMatrix(matrix);		//调用输入函数
	MultiplyMatrix(matrix,num);		//调用数乘函数
	OutputMatrix(matrix);			//调用输出函数

	return 1;
}