#include<iostream>
using namespace std;

int line,row;

//输入
void input_A(int ar[100])
{
	int i;

	//输入矩阵的行列
	cout<<"Please input the dimension of the matrix:"<<endl;
	cin>>line>>row;

	//输入数组元素
	cout<<"Please input the elements of the matrix:"<<endl;
	for(i=0;i<(line*row);i++)
		cin>>ar[i];
	
	//输出初始方阵
	cout<<"The original matrix is:"<<endl;
	for(i=0;i<(line*row);i++)
	{
		cout<<ar[i]<<' ';
		if((i+1)%row==0)
			cout<<endl;
	}
}

//数组的转置，输出
void trans_A(int ar[100])
{
	int i,j;
	//控制输出实现转置功能
	cout<<"The transposed matrix is:"<<endl;
	for(i=0;i<row;i++)								//输出row行		
	{
		for(j=i;j<=(i+(line-1)*row);j=j+row)		//每行输出line个
			cout<<ar[j]<<' ';
		cout<<endl;									//换行
	}	
}
			


int main()
{
	int ar[100];
	input_A(ar);		//调用输入函数
	trans_A(ar);		//调用转置输出函数

	return 0;
}