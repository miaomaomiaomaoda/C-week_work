#include<iostream>
#include<stdlib.h>
using namespace std;

typedef struct LNode *List;
typedef struct LNode{
	int Data;
	List Next;
}*PtrL;

int line,row;					//全局变量，存放行，列数据


//链表中查找第K个元素
List FindKth(List PtrL,int K)
{
	List p=PtrL;
	int i=1;
	while(p!=NULL&&i<K)
	{
		p=p->Next;
		i++;
	}
	if(i==K)	return p;		//如果找到第K个元素，返回其指针
	else return NULL;			//否则返回空指针
}

//链表元素插入
List Insert(List PtrL,int X,int i)
{
	List p,s;
	if(i==1)								//数据插入在表头
	{
		s=(List)malloc(sizeof(struct LNode));
		s->Data=X;
		s->Next=PtrL;
		return s;							//返回新表头指针
	}
	p=FindKth(PtrL,i-1);					//查找第（i-1）个结点，并返回指针给p

	if(p==NULL)								//没找到则输出参数错误
	{
		cout<<"参数错误"<<endl;
		return NULL;
	}
	else
	{
		s=(List)malloc(sizeof(struct LNode));
		//插入结点
		s->Data=X;
		s->Next=p->Next;
		p->Next=s;
		return PtrL;
	}
}

//输出函数
void Print(List PtrL)				
{
	List p=PtrL;
	int i=0;
	while(p)						//不断输出结点并将结点后移
	{
		cout<<p->Data<<' ';
		p=p->Next;
		i++;
		if(i%row==0)
			cout<<endl;
	}
}




//输入数据，输出初始矩阵
void input_A(List &PtrL)
{
	int i,temp;

	//输入矩阵的行列
	cout<<"Please input the dimension of the matrix:"<<endl;
	cin>>line>>row;

	//输入数组元素
	cout<<"Please input the elements of the matrix:"<<endl;
	for(i=1;i<=(line*row);i++)
	{
		cin>>temp;
		PtrL=Insert(PtrL,temp,i);					//调用insert函数，将元素插入链表末尾
	}
	
	//输出初始方阵
	cout<<"The original matrix is:"<<endl;
	Print(PtrL);	
}

//旋转输出函数
void out_A(List &PtrL,int angle)	
{
	int i,j;
	List p;
	//控制输出实现旋转操作
	if(angle==90)
	{
		cout<<"The matrix after rotating 90 is:"<<endl;
		for(i=1+(line-1)*row;i<=line*row;i++)				//控制行输出,以（line-1）*row为起始，共输出row行
		{
			for(j=i;j>=(i-(line-1)*row);j=j-row)			//控制列输出，共输出line列
			{
				p=FindKth(PtrL,j);
				cout<<p->Data<<' ';
			}
			cout<<endl;
		}
	}
	else if(angle==180)
	{
		cout<<"The matrix after rotating 180 is:"<<endl;
		for(i=line*row;i>0;i--)								//倒着输出即为180
		{
			p=FindKth(PtrL,i);
			cout<<p->Data<<' ';
			if((i-1)%row==0)								//满row换行
				cout<<endl;
		}
	}
	else if(angle==270)
	{
		cout<<"The matrix after rotating 270 is:"<<endl;
		for(i=row;i>0;i--)									//行输出，以（row-1）为起始，共输出row行
		{
			for(j=i;j<=i+(line-1)*row;j=j+row)				//控制列的输出，共输出line列
			{
				p=FindKth(PtrL,j);
				cout<<p->Data<<' ';
			}
			cout<<endl;
		}

	}
	else												//数据错误
		cout<<"You input a wrong angle!"<<endl;
}
int main()
{
	List PtrL=NULL;						//定义头指针
	int angle;							//角度
	char point;							//是否继续的标志
	input_A(PtrL);						//调用输入函数
	while(1)
	{
		cout<<"please input the angle:(90,180,270):";
		cin>>angle;						//旋转角度输入
		out_A(PtrL,angle);				//调用旋转输出函数

		//询问是否需要继续旋转
		cout<<"Do you want to continue?(Y/N)";
		cin>>point;					
		if(point=='N'||point=='n')		//标志point为N/n,退出循环
			break;
		
	}
	return 0;
}