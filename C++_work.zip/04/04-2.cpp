#include<iostream>
#include<iomanip>
using namespace std;

int line,row;					//行、列

//输入函数
void input_M(int* p)
{
	int i;

	//行列输入
	cout<<"Please input the dimension of the matrix:";
	cin>>line>>row;

	//数组元素输入
	cout<<"The elements of the matrix is:";
	for(i=0;i<line*row;i++)
		cin>>p[i];
	
	//初始矩阵输出
	for(i=0;i<line*row;i++)
	{
		cout.width(3);
		cout<<p[i]<<' ';
		if(0==((i+1)%row))
			cout<<endl;
	}
}
	


void handle_M(int* p)
{
	int i,j;
	//转置输出
	cout<<"The tansposed matrix is:"<<endl;
	for(i=0;i<row;i++)			//行输出控制
	{
		for(j=i;j<=(i+(line-1)*row);j=j+row)	//列输出控制
		{
			cout.width(3);		//宽度控制3
			cout<<p[j];
		}
		cout<<endl;
	}
}

int main()
{
	int* p=new int[100];			//动态分配
	char feature;
	while(1)
	{
		//转置输出
		input_M(p);						//调用输入函数
		handle_M(p);					//调用处理函数，实现转置和输出

		//程序重复判断
		cout<<"Do you want to continue to tanspose the matrix（Y/N）:";
		cin>>feature;					//继续标志
		
		if(feature=='n'||feature=='N')
			break;
	}
	delete [] p;					//释放内存
	return 0;
}