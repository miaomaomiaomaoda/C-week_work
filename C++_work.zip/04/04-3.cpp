#include<iostream>
#include<iomanip>
using namespace std;

int line,row;					//行、列

//输入函数
void input_M(int* p)
{
	int i;

	//行列输入
	cout<<"Please input the dimension of the matrix:";
	cin>>line>>row;

	//数组元素输入
	cout<<"The elements of the matrix is:";
	for(i=0;i<line*row;i++)
		cin>>p[i];

	//初始矩阵输入
	for(i=0;i<line*row;i++)
	{
		cout.width(3);			//宽度控制3
		cout<<p[i];
		if((i+1)%row==0)
			cout<<endl;
	}
}

//旋转输出函数
void rorate_M(int* p)
{
	int i,j;
	int angle;					//旋转角度
	
	//旋转角度输入
	cout<<"Please input the angle you want to ratate(90,180,270): ";
	cin>>angle;
	
	//角度选择
	if(angle==90)
	{
		cout<<"The matrix after ratating 90 is:"<<endl;
		for(i=(line-1)*row;i<line*row;i++)				//行输出控制，输出row行
		{
			for(j=i;j>=(i-(line-1)*row);j=j-row)		//列输出控制，输出line列
			{
				cout.width(3);
				cout<<p[j];
			}
			cout<<endl;
		}
	}
	else if(angle==180)			
	{
		cout<<"The matrix after ratating 180 is:"<<endl;
		for(i=line*row-1;i>=0;i--)						//逆向输出
		{
			cout.width(3);
			cout<<p[i];
			if(i%row==0)								//换行控制
				cout<<endl;
		}
	}
	else if(angle==270)
	{
		cout<<"The matrix after ratating 270 is:"<<endl;
		for(i=row-1;i>=0;i--)							//行输出控制，输出row行
		{
			for(j=i;j<=(i+(line-1)*row);j=j+row)		//列输出控制，输出line列
			{
				cout.width(3);							//宽度控制3
				cout<<p[j];
			}
			cout<<endl;
		}
	}
	else
		cout<<"You inpiut a wrong angle;"<<endl;
}


int main()
{
	int* p=new int[100];
	char feature;				//继续标志
	input_M(p);					//调用输入函数
	while(1)
	{
		rorate_M(p);			//调用旋转输出函数
		cout<<endl;
		//询问是否继续旋转
		cout<<"Do you want to continue to ratate the matrix(Y/N)?";
		cin>>feature;
		if(feature=='N'||feature=='n')
			break;
	}
	delete [] p;				//释放内存
	return 0;
}