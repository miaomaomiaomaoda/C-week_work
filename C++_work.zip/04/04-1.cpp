#include<iostream>
#include<iomanip>
using namespace std;

int line,row;			//存放行列

int input_M(int* p)		//输入函数
{
	int i;	
	int num;


	//行列输入
	cout<<"Please input the dimension of the matrix:";
	cin>>line>>row;

	//数组元素输入
	cout<<"Please input the elments of the matixs:";
	for(i=0;i<line*row;i++)
		cin>>p[i];

	//乘数输入
	cout<<"Please input the num:";
	cin>>num;

	//初始矩阵输出
	cout<<"The original matrix is:"<<endl;
	for(i=0;i<line*row;i++)		//矩阵输出
	{
		cout.width(3);
		cout<<p[i]<<' ';
		if(0==((i+1)%row))			//换行
			cout<<endl;
	}
	return num;
}

//实现数乘操作并输出
void mutiply(int* p,int num)
{
	int i;
	
	//数乘操作
	for(i=0;i<line*row;i++)
		p[i]=p[i]*num;

	//输出矩阵
	cout<<"The matrix mutiplied by a number is:"<<endl;
		for(i=0;i<line*row;i++)		//矩阵输出
	{
		cout.width(3);
		cout<<p[i]<<' ';
		if(0==((i+1)%row))		//换行
			cout<<endl;
	}
}

int main()
{
	int *p=new int[100];			//动态分配
	int num;
	num=input_M(p);					//调用输入函数，并返回乘数
	mutiply(p,num);					//调用函数进行数乘操作并输出
	delete	[] p;					//释放内存
	return 0;
}
