#include<iostream>
#include<string>
using namespace std;

//基类定义
class A{
	int i;
protected:
	char c;
public:
	string s;
	A(int tempi,char tempc,string temps):i(tempi),c(tempc),s(temps){};
	void show(){cout<<"A::i="<<i<<"  A::c="<<c<<"  A::s="<<s<<endl;};
};

class B{
	int i;
protected:
	char c;
public:
	string s;
	B(int tempi,char tempc,string temps):i(tempi),c(tempc),s(temps){};
	void show(){cout<<"B::i="<<i<<"  B::c="<<c<<"  B::s="<<s<<endl;};
};

//子类定义
class C:public A,public B{
public:
	C(int i1,char c1,string s1,int i2,char c2,string s2):A(i1,c1,s1),B(i2,c2,s2){};
};


int main(){
	C c(1,'a',"as",2,'b',"bs");
	//c.show();
	c.A::show();		//输出A
	c.B::show();		//输出B
	return 0;
}