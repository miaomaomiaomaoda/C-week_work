#include<iostream>
#include<string>
using namespace std;

class A{
	int x;
protected:
	char y;
public:
	string z;
	A(int a,char b,string c):x(a),y(b),z(c){};
	void show(){cout<<"A::x="<<x<<"  A::y="<<y<<"  A::z="<<z<<endl;};
};

class B:virtual	public A{
public:
	B(int a,char b,string c):A(a,b,c){};
};

class C:virtual public A{
public:
	C(int a,char b,string c):A(a,b,c){};
};

class D:public B,public C{
public:
//	D(int a,char b,string c,int d,char e,string f):B(a,b,c),C(d,e,f),A(){};									//作用域
	D(int a,char b,string c,int d,char e,string f,int g,char h,string s):B(a,b,c),C(d,e,f),A(g,h,s){};		//虚继承，需要直接调用虚基类的构造函数
};



int main(){
	A a(96,'h',"xb");
	a.show();
	cout<<"基类所占空间大小为: "<<sizeof(a)<<endl;
/*
//  
	1.作用域解决路径二义性	
	D d(98,'b',"bs",99,'c',"cs");
	//d.show();
	d.B::show();
	d.C::show();
	cout<<"用作用域规则解决路径二义性的时候，派生类对象所占空间大小为: "<<sizeof(d)<<endl;
*/
	//2.虚继承解决路径二义性
	D d(98,'b',"bs",99,'c',"cs",96,'a',"as");
	d.B::show();
	d.C::show();
	d.show();
	cout<<"用虚继承方式解决路径二义性的时候，派生类对象所占空间大小为: "<<sizeof(d)<<endl;
	return 0;
}