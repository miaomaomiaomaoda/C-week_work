#include<iostream>
#include<string>
using namespace std;
//虚继承的目的是令某个类做出声明，承诺愿意共享它的基类（即虚基类）。在这种情况下，不管虚基类在继承体系中出现了多少次，在派生类中只包含唯一共享的虚基类副本，即只有一个副本
//注意构造空的构造函数
//虚基类构造函数只能调用一次，即让最下层的子类调用

//图像类
class Figure{
public:
    int sidenum;					//边数
    Figure(int temp) : sidenum(temp) { 
        cout << "The figure has " << sidenum << " sides" << endl; 
    };
    Figure(){};
};

//对角线互相垂直的四边形子类
class Quadrangle1:virtual public Figure{
public:
	Quadrangle1(int temp):Figure(temp){};
    Quadrangle1() {
        cout << "This is a Quadrangle with two diagonal lines perpendicular to each other!" << endl;
    };
};

//平行四边形子类
class Parallelogram:virtual public Figure{
public:
	Parallelogram(int temp):Figure(temp){};
    Parallelogram() { 
        cout << "This is a Parallelogram!" << endl; 
    };
};

//四个角均为直角的四边形之类
class Quadrangle2:virtual public Figure{
public:
	Quadrangle2(int temp):Figure(temp){};
    Quadrangle2() { 
        cout << "This is a Quadrangle with four 90 degree interior angles!" << endl; 
    };
};


//菱形类
class Rhombus:virtual public Quadrangle1,virtual public Parallelogram{
public:
    int sidelength;				//边长
    Rhombus(int temp) : sidelength(temp) { 
        cout << "This is a Rhombus!" << endl; 
    };
};

//派生类：矩形类Rectangle
class Rectangle:virtual public Quadrangle2,virtual public Parallelogram{
public:
    float angle;				//角度
    Rectangle(float temp) : angle(temp) { 
        cout << "This is a rectangle!" << endl; 
    };
};

//派生类：正方形类Square
class Square:public Rhombus,public Rectangle{
public:
    Square(int temp1, int temp2, float temp3) : Figure(temp1), Rhombus(temp2), Rectangle(temp3) { 
        cout << "The figure is a square!" << endl;
        cout << "All angles of the square are " << angle << " degree interior angles!" << endl;
        cout << "The sidelength of the square is " << sidelength << " !" << endl;
        cout << "The area of the square is " << sidelength * sidelength << " !" << endl;
    };
};

int main(){
	Square s(4,10,90);	
	return 0;
}
