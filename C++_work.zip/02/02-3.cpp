#include<iostream>
using namespace std;
int Queen[8][8];					//8*8的棋盘，存放皇后位置
int map=0,num;						//八皇后问题可能情况数目，方案数
int x,y;							//初始横坐标，纵坐标

//结果输出
void print()
{		
	cout<<"方案"<<map<<":"<<endl;
	for(int line=0;line<8;line++)
	{
		for(int row=0;row<8;row++)
		{
			if(Queen[line][row]==1)			//有皇后标记，则输出#
				cout<<"#";
			else
				cout<<"+";
		}
		cout<<endl;
	}
	cout<<endl;
}

//打印结果
void out()
{
	cout<<"方案"<<num<<":"<<endl;
	for(int line=0;line<8;line++)
	{
		for(int row=0;row<8;row++)
		{
			if(Queen[line][row]==1)			//皇后在第line+1行，第row+1列		
				cout<<"#";
			else
				cout<<"+";
		}
		cout<<endl;
	}
	cout<<endl;
}

//判断函数，判断结点是否满足皇后所需要求
bool check(int line,int row)
{
	//检查行列
	for(int line_0=0;line_0<8;line_0++)
	{
		if(Queen[line_0][row]==1)
			return false;
		if(Queen[line][line_0]==1)
			return false;
	}
	//检查左对角线
	for(int line_1=line-1,row_1=row-1;line_1>=0&&row_1>=0;line_1--,row_1--)		
	{
		if(Queen[line_1][row_1]==1)
			return false;
	}
	//检查右对角线
	for(int line_2=line-1,row_2=row+1;line_2>=0&&row_2<=7;line_2--,row_2++)
	{
		if(Queen[line_2][row_2]==1)
			return false;
	}
	return true;
}

//函数，寻找皇后的全部可能情况
void findQueen(int line)
{
	if(line>7)					//八皇后的解
	{
		map++;
		print();				//打印八皇后的解
	}
	for(int row=0;row<8;row++)	//回溯递归
	{
		if(check(line,row))		//检查皇后位置是否满足要求
		{
			Queen[line][row]=1;
			findQueen(line+1);
			Queen[line][row]=0;	//不满足条件，递归返回，清空数据，避免数据影响
		}
	}
}

//已知一个皇后位置寻求其他皇后位置的可能情况
void firstQueen(int line)		
{
	if(line>7)					//八皇后的解
	{
		if(Queen[x][y]==1)		//输入位置(x,y)有皇后位置，则
		{
			num++;
			out();				//打印满足输入位置存在皇后的8*8棋盘
		}
	}
	for(int row=0;row<8;row++)	//回溯递归
	{
		if(check(line,row))		//检查皇后位置是否满足要求
		{	
			Queen[line][row]=1;
			firstQueen(line+1);
			Queen[line][row]=0;	//不满足条件，递归返回，清空数据，避免数据影响
		}
	}
}

void main()
{
	cout<<"八皇后解答:"<<endl;
	//1.八皇后问题可能情况数
	findQueen(0);
	cout<<"八皇后问题可能情况共有:"<<map<<endl;

	//2.输入一个皇后位置后的可能情况数
	cout<<"请输入一个皇后的位置(x,y)，示例:3 5"<<endl;
	cin>>x>>y;
	x--;
	y--;
	firstQueen(0);
}

