#include<iostream>
using namespace std;

//水仙花数判断函数
int Judge_Narnum(int num)
{
	int hund,dec,unit;				//定义变量，分别用于存储百位十位个位
	int out;						//存放立方和的变量

	//按位存储
	hund=num/100;
	dec=(num/10)%10;
	unit=num%10;

	//计算立方和并判断
	out=(hund*hund*hund)+(dec*dec*dec)+(unit*unit*unit);			

	if(out==num)					//判断并返回值
		return 1;
	else return 0;

}


int main()
{

	char function;
	int i=0,number=0;

	//功能选择，1.水仙花数判断	2.输出99-1000之间的水仙花数
	cout<<"请选择功能,y代表水仙花判断，n代表输出99-1000之间的水仙花数: ";
	cin>>function;

	if(function=='y')				//1.水仙花判断函数
	{
		while(1)
		{
			//数据输入
			cout<<"Please input a number: ";
			cin>>number;
			
			//判断并输出
			Judge_Narnum(number)?cout<<number<<"是水仙花数"<<endl:cout<<number<<"不是水仙花数"<<endl;

			//询问是否需要继续判断，不需要则跳出循环
			cout<<"是否需要继续判断（y代表yes，n表示no）?";
			cin>>function;
			if(function=='n')
				break;

		}
	}
	else							//2.输出99-1000之间的水仙花数
	{
		for(i=100;i<=999;i++)					//循环判断输出
		{
			if(Judge_Narnum(i)==1)
				cout<<i<<"\t";
		}
		cout<<endl;
	}
	return 1;
}
