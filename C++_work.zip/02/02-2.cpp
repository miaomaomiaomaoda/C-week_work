#include<iostream>
using namespace std;

//移动，输出函数
void move (int num,int M,int N)					
{
	cout<<"编号为"<<num<<"移动:"<<M<<"->"<<N<<endl;
}

//汉诺塔递归函数
void hanoi(int n,int A,int B,int C)
{
	if(n==1)						//圆盘只有一个时，只需将其从A塔移到C塔
		move(1,A,C);				//将编号为1的圆盘从A移到C
	else
	{								//否则
		hanoi(n-1,A,C,B);			//递归n-1,把A塔上编号1~n-1的圆盘移到B上，以C为辅助塔
        move(n,A,C);				//把A塔上编号为n的圆盘移到C上
        hanoi(n-1,B,A,C);			//递归n-1,把B塔上编号1~n-1的圆盘移到C上，以A为辅助塔
        
    }
}

int main()
{
	int A=1,B=2,C=3;						
	int num;
	char point;						//指示标志，确定是否继续
	
	while(1)
	{
		//输入数据，调用汉诺塔并输出
		cout<<"Please input a number:";
		cin>>num;
		hanoi(num,A,B,C);			//调用汉诺塔函数
		
		//询问是否需要继续？
		cout<<"Do you want to go on?(y or n)";
		cin>>point;
		if(point=='n')				//不继续则跳出循环
			break;
	}
	return 1;
}
