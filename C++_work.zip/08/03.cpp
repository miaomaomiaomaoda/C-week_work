#include<iostream>
#include<string>
using namespace std;

//类定义
class Person{
    public:
        string name;
        string gender;
        int age;
};

class Student: public Person{
    int sno;
    string major;
    public:
        Student(){};//构造函数
        //~Student();//析构函数
        void Enroll(){
            cin >> sno >> name >> gender >> age >> major;
            cout << "一个学生注册完成!" << endl;
        };    //开学登记注册函数
        void ShowStudent(){
            cout << sno << "  " << name << "  " << gender << " " << age << "  " << major << endl;
        };      //学生信息显示函数
};

class Teacher: public Person{
    int tno;
    string college;
    public:
        Teacher(){};      //构造函数
        //~Teacher();
        void Recruit(){
           cin >> tno >> name >> gender >> age >> college;
           cout << "一个教师注册完成!" << endl;
        };       //教师招聘函数
        void ShowTeacher(){
            cout << tno << "  " << name << "  " << gender << "  " << age << "  " << college << endl;
        };  //教师信息显示函数
};

class Administrator : public Person{
    int ano;
    string section;
    public:
        Administrator(){};
        //~Administrator();
        void Employ(){
            cin >> ano >> name >> gender >> age >> section;
            cout << "一个管理人员注册完成!" << endl;
        };               //管理人员雇佣函数
        void ShowAdministrator(){
            cout << ano << "  " << name << "  " << gender << "  " << age << "  " << section << endl;
        }; //管理人员信息显示函数
};

class University{
    string uname;
    string uaddress;
    Student Stu[200];
    Teacher Tea[200];
    Administrator Adm[200];

    //管理系统中当前学生数，教师数和管理人员数（-1）
    int Snum, S_point;
    int Tnum, T_point;
    int Anum, A_point;

public:
    // 学校初始化
        University(){
            cout << "请输入大学的名称和地址: ";
            cin >> uname >> uaddress;
            //初始化学生数、教师数和管理人员数
            Snum = 0;   S_point = 0;
            Tnum = 0;   T_point = 0;
            Anum = 0;   A_point = 0;
        };
        //~University();
        void TermBegin();             //学校开学注册管理函数
        void ShowUniversity();        //信息显示函数
};
void University::TermBegin(){
    cout << "*******************开学注册*******************" << endl;
    int i;
    //学生注册
    cout << "***进入学生注册***" << endl;
    cout << "请输入注册的学生数:";
    cin >> Snum;
    if(Snum!=0){
        cout << "请按照如下格式输入" << Snum << "个学生的信息:" << endl
             << "(学号 姓名 性别 年龄 专业)" << endl;
        for (i = S_point; i < S_point+Snum;i++)
            Stu[i].Enroll();
        S_point += Snum;
    }

    cout << "***进入教师注册***" << endl;
    //教师注册
    cout << "请输入注册的教师数:";
    cin >> Tnum;
    if(Tnum!=0){
        cout << "请按照如下格式输入"<<Tnum<<"个教师的信息:" << endl
            << "(工号 姓名 性别 年龄 学院)" << endl;
        for (i = T_point; i < T_point+Tnum;i++)
            Tea[i].Recruit();
        T_point += Tnum;
    }


    //管理人员注册
    cout << "***进入管理人员注册***" << endl;
    cout << "请输入注册的管理人员数:";
    cin >> Anum;
    if(Anum!=0){
    cout << "请按照如下格式输入"<<Anum<<"2个管理人员的信息:" << endl
        << "(工号 姓名 性别 年龄 部门)" << endl;
    for (i = A_point; i < A_point+Anum;i++)
        Adm[i].Employ();
    A_point += Anum;
    }
};             //学校开学注册管理函数

void University::ShowUniversity(){
    cout << "*******************管理系统内学校及其相关数据展示*******************" << endl;
    //学校信息
    cout << "该大学的基本信息展示如下：" << endl;
    cout << uname << uaddress << endl;
    int i;
    //学生信息
    if(S_point!=0){
        cout << "该大学学生信息显示如下:" << endl;
        for (i = 0; i < S_point;i++)
            Stu[i].ShowStudent();
    }
    else 
        cout << "该大学无学生信息！" << endl;

    //教师信息
    if(T_point!=0){
        cout << "该大学教师信息显示如下:" << endl;
        for (i = 0; i < T_point; i++)
            Tea[i].ShowTeacher();
    }
    else
        cout << "该大学无教师信息！"<<endl;

    //管理人员信息
    if(A_point!=0){
        cout<< "该大学管理人员信息显示如下:" << endl;
        for (i = 0; i < A_point; i++)
            Adm[i].ShowAdministrator();
    }
    else
        cout << "该大学无管理人员信息！" << endl;

};        //信息显示函数

//主函数
int main()
{
    University Uni;
    Uni.TermBegin();
    Uni.ShowUniversity();
    return 0;
}

//可实现多个学校信息的录入，创建University类数组即可
//本程序只能实现最开始的注册显示并不能实现其他操作