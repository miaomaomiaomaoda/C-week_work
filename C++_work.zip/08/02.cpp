#include <iostream>
#include <string>
using namespace std;

//祖先类
class Ancestor{
    string Aname;
    char Agender;
    public:
        Ancestor(string a, char b) : Aname(a), Agender(b){
            cout << "The Ancestor is constructed!" << endl;
        };
        void displayAncestor(){
            cout << "The infomation of my Ancestor is " << Aname << " " << Agender << endl;
        };
        ~Ancestor(){
            cout << "The Ancestor is unconstructed!" << endl;
        }
};

//祖父类，继承祖先类
class GrandFather: public Ancestor{
    string Gname;
    char Ggender;
    public:
        GrandFather(string a, char b, string c, char d) : Ancestor(a, b), Gname(c), Ggender(d){
            cout << "The GrandFather is constructed!" << endl;
        };
        void displayGrandFather(){
            displayAncestor();
            cout << "The infomation of my GrandFather is " << Gname << " " << Ggender << endl;
        };
        ~GrandFather(){
            cout << "The GrandFather is unconstructed!" << endl;
        }
};

//父亲类，继承祖父类
class Father: public GrandFather{
    string Fname;
    char Fgender;
    public:
    //子类的构造函数只需要构造父类
        Father(string a, char b, string c, char d, string e, char f) : GrandFather(a,b,c,d), Fname(e), Fgender(f){
            cout << "The Father is constructed!" << endl;
        };
        void displayFather(){
            displayGrandFather();
            cout << "The infomation of my Ftaher is " << Fname << " " << Fgender << endl;
        };
        ~Father(){
            cout << "The Father is unconstructed!" << endl;
        }
};

//兄弟类，继承Father类
class Brother: public Father{
    string Bname;
    char Bgender;
    public:
        Brother(string a, char b, string c, char d, string e, char f, string g, char h) : Father(a, b, c, d, e, f), Bname(g), Bgender(h){
            cout << "The Brother is constructed!" << endl;
        };
        void displayBrother(){
            cout << "The infomation of my Brother is " << Bname << " " << Bgender << endl;
        };
        ~Brother(){
            cout << "The Brother is unconstructed!" << endl;
        }
};

//姐妹类，公共继承Father
class Sister: public Father{
    string Sname;
    char Sgender;
    public:
        Sister(string a, char b, string c, char d, string e, char f, string g, char h) : Father(a, b, c, d, e, f), Sname(g), Sgender(h){
            cout << "The Sister is constructed!" << endl;
        };
        void displaySister(){
            cout << "The infomation of my Sister is " << Sname << " " << Sgender << endl;
        };
        ~Sister(){
            cout << "The Sister is unconstructed!" << endl;
        }
};

//自己类，继承Father类
class Me: public Father{
    string Mname;
    char Mgender;
    Brother Bro;
    Sister Sis;

public:
    Me(string a, char b, string c, char d, string e, char f, string g, char h,Brother bro,Sister sis) : Father(a, b, c, d, e, f), Mname(g), Mgender(h),Bro(bro),Sis(sis){
        cout << "The Me is constructed!" << endl;
    };          //构造函数
    void displayMe(){
        displayFather();
        Bro.displayBrother();
        Sis.displaySister();
        cout << "The infomation of Me is " << Mname << " " << Mgender << endl;
    };
    ~Me(){
        cout << "The Me is unconstructed!" << endl;
    }           //析构函数
};

//主函数体
int main(){
	Brother bro("ZX", 'M', "ZF", 'M', "FQ", 'M', "Bro", 'M');
	Sister  sis("ZX", 'M', "ZF", 'M', "FQ", 'M', "Sis", 'F');
	Me me("ZX", 'M', "ZF", 'M', "FQ", 'M', "Me",'M', bro, sis);
	me.displayMe();
    return 0;
}
