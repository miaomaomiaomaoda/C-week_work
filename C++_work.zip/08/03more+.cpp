#include<iostream>
#include<string>
#define password 1335
using namespace std;

//相比于3，功能更完善

//类定义
class Person{
    public:
        string name;
        string gender;
        int age;
};

class Student: public Person{
    int sno;
    string major;
    public:
        Student(){};//构造函数
        //~Student();//析构函数
        void Enroll(){
            cin >> sno >> name >> gender >> age >> major;
            cout << "一个学生注册完成!" << endl;
        };                              //学生登记注册函数
        void ShowStudent(){
            cout << sno << "  " << name << "  " << gender << " " << age << "  " << major << endl;
        };                              //学生信息显示函数
        void LikeOrNot(){};             //上课教师印象评价函数
};

class Teacher: public Person{
    int tno;
    string college;
    string Course[200];
public:
    int num;
    Teacher(){}; //构造函数
    //~Teacher();
    void Recruit()
    {
        cin >> tno >> name >> gender >> age >> college;
        cout << "一个教师注册完成!" << endl;
        };       //教师招聘函数
    void ShowTeacher(){
        cout << tno << "  " << name << "  " << gender << "  " << age << "  " << college << endl;
    };      //教师信息显示函数
    void TCourse();         //课程管理函数
    int Gettno() { return tno; };
    void SetTCourse(string& Cname) { 
        Course[num]=Cname;
        num++;
    };          //将课程放入
    void ShowTCourse(){
        for (int i = 0; i < num;i++)
            cout << "  " << Course[i];
    }
};

class Administrator : public Person{
    int ano;
    string section;
    public:
        Administrator(){};
        //~Administrator();
        void Employ(){
            cin >> ano >> name >> gender >> age >> section;
            cout << "一个管理人员注册完成!" << endl;
        };               //管理人员雇佣函数
        void ShowAdministrator(){
            cout << ano << "  " << name << "  " << gender << "  " << age << "  " << section << endl;
        };              //管理人员信息显示函数
        void ManageStudent(){};     //学生学籍管理函数
        void ArrangeCourse(){};     //教师课程管理函数
};

class University{
    string uname;
    string uaddress;
    Student Stu[200];
    Teacher Tea[200];
    Administrator Adm[200];

    //管理系统中当前学生数，教师数和管理人员数（-1）
    int Snum, S_point;
    int Tnum, T_point;
    int Anum, A_point;

public:
    // 学校初始化
        University(){
            cout << "请输入大学的名称和地址: ";
            cin >> uname >> uaddress;
            //初始化学生数、教师数和管理人员数
            Snum = 0;   S_point = 0;
            Tnum = 0;   T_point = 0;
            Anum = 0;   A_point = 0;
        };
        //~University();
        void TermBegin();             //学校开学注册管理函数
        void ShowUniversity();        //信息显示函数
        void AddTCourse();       //教师课程添加
        void ShowTCourse();     //教师课程显示
};

void University::TermBegin(){
    //学生注册
    cout << "请输入注册的学生数:";
    cin >> Snum;
    cout << "请按照如下格式输入"<<Snum<<"个学生的信息:" << endl
                 << "(学号 姓名 性别 年龄 专业)" << endl;
    int i;
    for (i = S_point; i < S_point+Snum;i++)
        Stu[i].Enroll();
    S_point += Snum;

    //教师注册
    cout << "请输入注册的教师数:";
    cin >> Tnum;
    cout << "请按照如下格式输入"<<Tnum<<"个教师的信息:" << endl
         << "(工号 姓名 性别 年龄 学院)" << endl;
    for (i = T_point; i < T_point+Tnum;i++)
    { 
        Tea[i].Recruit();
        Tea[i].num = 0;        
    }
    T_point += Tnum;

    //管理人员注册
    cout << "请输入注册的管理人员数:";
    cin >> Anum;
    cout << "请按照如下格式输入" << Anum << "个管理人员的信息:" << endl
         << "(工号 姓名 性别 年龄 部门)" << endl;
    for (i = A_point; i < A_point + Anum; i++)
        Adm[i].Employ();
    A_point += Anum;
};                          //学校注册管理函数

void University::ShowUniversity(){
    cout << "*******************管理系统内学校及其相关数据展示*******************" << endl;
    //学校信息
    cout << "该大学的基本信息展示如下：" << endl;
    cout << uname << uaddress;

    int i;
    //学生信息
    cout << "该大学学生信息显示如下:" << endl;
    for (i = 0; i < S_point;i++)
        Stu[i].ShowStudent();
    
    //教师信息
    cout << "该大学教师信息显示如下:" << endl;
    for (i = 0; i < T_point;i++)
        Tea[i].ShowTeacher();

    //管理人员信息
    cout << "该大学管理人员信息显示如下:" << endl;
    for (i = 0; i < A_point;i++)
        Adm[i].ShowAdministrator();

};        //信息显示函数

int GetIN(){
    int pass;
    cout << "输入E进入管理人员登录界面，输入Q退出.........." << endl;
    char A;
    while(1){
        cin >> A;
        if(A=='Q')
            return 0;
        else if(A=='E')
            break;
        else
            cout << "输入错误，请重新输入!" << endl;
    }
    system("cls");      //清屏
    cout << "************************管理人员登录窗口************************" << endl;
    int i = 0;
    cout << "注：密码三次输入错误，将退出程序!" << endl;
    while(1){
    cout <<"请输入密码:";
    cin >> pass;
    if(pass!=password){
        i++;
        cout << "密码错误，请重新输入!" << endl;
        if(i==3){
            cout << "密码已输入错误3次，程序关闭!" << endl;
            system("Pause");
            return 0;
        }       
    }
    else
        return 1;       //密码正确
    }
}

//教师课程添加
void University::AddTCourse()
{
    int i;
    //教师信息
    cout << "该大学教师信息显示如下:" << endl;
    for (i = 0; i < T_point;i++)
        Tea[i].ShowTeacher();
   
    int num;                //添加课程条数
    cout <<"请输入需要添加课程的总条数:";
    cin >> num;

    string T_course;
    int tno;                //工号
    cout << "请输入添加的课程及老师：(C++程序设计 工号)" << endl;
    for (i = 0; i < num;i++){
        cin >> T_course >>tno;
        for (int j = 0; j <T_point;j++){
            if(Tea[j].Gettno()==tno){               //工号匹配，传入课程
                Tea[j].SetTCourse(T_course);
            }
        }
    }
}

void University::ShowTCourse(){
    int i;
    //教师信息
    cout << "该大学教师课程显示如下:" << endl;
    for (i = 0; i < T_point;i++){
        cout << Tea[i].name;
        Tea[i].ShowTCourse();
        cout << endl;
    }
}

//功能选择函数
void Function(University& Uni){
    int fct;
    char p;
    while(1){
        cout << "请选择想要执行的操作：（1.学生、教师、管理人员添加   2.输出管理内学校及其相关信息 3.添加教师课程 4.教师课程显示"<<endl;
        cin >> fct;
        if(fct==1){
            cout << "*******************添加*******************" << endl;
            Uni.TermBegin();
        }
        else if(fct==2)
            Uni.ShowUniversity();
        else if(fct==3)
            Uni.AddTCourse();
        else if(fct==4){
            Uni.ShowTCourse();
        }
        else
            cout << "其它功能尚未编写！" << endl;
        cout << "是否需要继续操作?(Y/N) ";
        cin >> p;
        if(p=='N'||p=='n')
            break;
    }
}




//主函数
int main()
{
    University Uni;
    cout << "*******************开学注册*******************" << endl;
    Uni.TermBegin();
    Uni.ShowUniversity();
    if(GetIN()==0)
        return 1;           //退出程序
    cout << "登录成功！" << endl;
    Function(Uni);
    return 0;
}

//可实现多个学校信息的录入，创建University类数组即可