#include<iostream>
using namespace std;

class CBase{
public:
	int x;
	CBase(int a,int b,int c):x(a),y(b),z(c){};	//基类构造函数
	void GetCBasez(){cout<<z<<endl;};			//基类z属于私有变量，子类无法访问，创建该函数用于子类中调用输出z
protected:
	int y;
private:
	int z;
};

//私有继承,x,y,z均变成私有,CDeriveA外无法直接访问
class CDeriveA:private CBase{
private:
	int ax;
	void showx(){cout<<"CBase.x="<<x<<endl;}			
	void showax(){cout<<"CDriveA.ax="<<ax<<endl;}		
public:
	int ay;
	CDeriveA(int a,int b,int c,int d,int e,int f):CBase(a,b,c),ax(d),ay(e),az(f){};		//子类构造函数
	CBase::y;																			//访问声明，调整y的访问域,使得CDeriveA外能够直接访问y
	void showy(){cout<<"CBase.y="<<y<<endl;}
	void showay(){cout<<"CDriveA.ay="<<ay<<endl;}

	//访问ax
	void showAxandBasexfromOuterA(){
		showx();
		showax();
	};						//类外访问私有变量ax
	void showAzandBasezfromOuterA(){
		showz();
		showaz();
	};						//类外访问保护变量az
	

protected:
	int az;
	void showz(){cout<<"CBase.z=";GetCBasez();}
	void showaz(){cout<<"CDriveA.az="<<az<<endl;}

};

//保护继承
class CDeriveB:protected CBase{
private:
	int bx;
	void showx(){cout<<"CBase.x="<<x<<endl;}			
	void showbx(){cout<<"CDriveB.bx="<<bx<<endl;}		
public:
	int by;
	CDeriveB(int a,int b,int c,int d,int e,int f):CBase(a,b,c),bx(d),by(e),bz(f){};		//构造函数
	void showy(){cout<<"CBase.y="<<y<<endl;}
	void showby(){cout<<"CDriveB.by="<<by<<endl;}

	//成员函数
	void showBxandBasexfromOuterB(){
		showx();
		showbx();
	};					//类外访问私有变量bx
	void showBzandBasezfromOuterB()
	{
		showz();
		showbz();
	};					//类外访问保护变量bx
protected:
	int bz;
	void showz(){cout<<"CBase.z=";GetCBasez();}
	void showbz(){cout<<"CDriveB.bz="<<bz<<endl;}

};

//公有继承
class CDeriveC:public CBase{
private:
	int cx;
	void showx(){cout<<"CBase.x="<<x<<endl;}			
	void showcx(){cout<<"CDriveC.cx="<<cx<<endl;}		
public:
	int cy;
	CDeriveC(int a,int b,int c,int d,int e,int f):CBase(a,b,c),cx(d),cy(e),cz(f){};		//构造函数
	void showy(){cout<<"CBase.y="<<y<<endl;}
	void showcy(){cout<<"CDriveC.y="<<cy<<endl;}

	//成员函数
	void showCxandBasexfromOuterC(){
		showx();
		showcx();
	};				//类外访问私有变量bx
	void showCzandBasezfromOuterC(){
		showz();
		showcz();
	};				//类外访问保护变量bx
protected:
	int cz;
	void showz(){cout<<"CBase.z=";GetCBasez();}
	void showcz(){cout<<"CDriveC.cz="<<cz<<endl;}

};

//先输出基类，再输出子类
int main(){

	//子类CDeriveA操作
	CDeriveA ca(11,12,13,14,15,16);
	ca.showAxandBasexfromOuterA();
	ca.showy();
	ca.showay();
	ca.showAzandBasezfromOuterA();
	cout << "访问域调整:";
	cout<<"CBase.y="<<ca.y<<endl;								//访问声明调整父类y的访问域
	
	//子类CDeriveB操作
	CDeriveB cb(21,22,23,24,25,26);
	cb.showBxandBasexfromOuterB();
	cb.showy();
	cb.showby();
	cb.showBzandBasezfromOuterB();

	//子类CDeriveC操作
	CDeriveC cc(31,32,33,34,35,36);
	cc.showCxandBasexfromOuterC();
	cc.showy();
	cc.showcy();
	cc.showCzandBasezfromOuterC();
    return 0;
}

