#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	int i,j,point,index=0;
	char str_1,str_2;
	char str_3[10];								//作交换字符串临时存储用
	char char_string[5][10];					//二维字符数组存放字符串


	//字符串的输入
	cout<<"请输入五个字符串:"<<endl;
	for(i=0;i<5;i++)						
		cin>>char_string[i];


	//选择排序修改字符串顺序
	for(i=0;i<4;i++)						
	{
		index=i;													//index存放每轮最小字符串序号，初始为i
		
		for(j=i+1;j<5;j++)											//每轮找最小，更新index
		{
			point=strcmp(char_string[index],char_string[j]);		//strcmp比较字符串大小，将返回值存入point
			
			if(point>0)												//point大于0则字符串1大于字符串2，更新index
				index=j;
		}


		//交换i号和index号字符串
		strcpy(str_3,char_string[i]);
		strcpy(char_string[i],char_string[index]);
		strcpy(char_string[index],str_3);
	}


	//排序后字符串输出
	cout<<"排好序的字符串如下图所示:"<<endl;
	for(i=0;i<5;i++)
		cout<<char_string[i]<<endl;

	return 1;
}
		
