#include<iostream>
using namespace std;

double fact(int num)							//通过递归求阶乘
{
	double fact_out;
	if(num==0)									//终止条件
		fact_out=1;
	else
		fact_out=fact(num-1)*num;
	return fact_out;

}

double sum(int num)								//通过递归求阶乘和
{
	double sum_out;					
	if(num==0)									//终止条件
		sum_out=1;
	else
		sum_out=sum(num-1)+fact(num);
	return sum_out;
}


int main()
{
	int i,number;

	//输入数据
	cout<<"Please enter the number:";		
	cin>>number;								
	cout<<"数字\t"<<"阶乘\t"<<"阶乘和"<<endl;

	//求阶乘&&阶乘和
	for(i=0;i<=number;i++)
	{
		cout<<i<<"\t";							//数字
		cout<<fact(i)<<"\t\t";					//阶乘
		cout<<sum(i)<<endl;						//阶乘和	
	}

	//输出0到num的阶乘和
	cout<<"The sum is "<<sum(number)<<endl;		

	return 1;
}