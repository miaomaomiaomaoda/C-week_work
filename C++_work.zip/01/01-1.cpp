#include<iostream>
#include<cmath>
using namespace std;

//素数判断函数,m不能被2到根号m间任一整数整除,m必定是素数
int Judge_prime(int data)			
{
	int i,Judge,point=1;
	Judge=sqrt(data);				//求平方根
	
	for(i=2;i<=Judge;i++)			//用循环体尝试从2到data的平方根整除，并用point作为判断标志
	{
		if(data%i==0)
		{
			point=0;				//能被整除，则不为素数，point标志指向0，并跳出循环
			break;
		}
	}
	if(point==1)					//素数返回1
		return 1;
	else 
		return 0;
}


int main()
{
	int data,i;
	char function;

	//功能选择
	cout<<"请输入y/n决定实现的功能，y是判断输入的数是否素数，n是输出100以内的所有素数"<<endl;
	cin>>function;

	
	if(function=='y')						//功能1.判断输入的数是否为素数
	{

		while(1)
		{
			cout<<"输入的数字为:";
			cin>>data;
			if(data<2)						//错误数据输出错误
				cout<<"数据错误"<<endl;
			else							//将data传入素数判断函数，根据结果决定输出
			{
				cout<<data;
				Judge_prime(data)?cout<<"是素数"<<endl:cout<<"不是素数"<<endl;
			}

			//询问是否需要继续判断素数
			cout<<"是否需要继续判断素数(y-是，n-否)?";
			cin>>function;
			if(function=='n')				//不需要，则跳出循环
				break;
		}
	}
	else									//功能2.输出100以内所有素数
	{
		cout<<"100以内的素数如下:"<<endl;
		for(i=2;i<=100;i++)					//2-100循环判断是否为素数，输出其中的素数
		{	
			if(Judge_prime(i))
				cout<<i<<"\t";
		}
		cout<<endl;
	}
	return 0;
}