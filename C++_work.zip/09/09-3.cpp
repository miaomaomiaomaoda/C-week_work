#include<iostream>
#include<string>
using namespace std;

//继承类指针赋给基类指针
class Automobile;			//提前声明，便于Park类中使用Automobie相关数据

class Park{
int N,income,numAuto;
Automobile **spaces;        //二维指针，N个停车位，每个停车位指向一个Automobile类，指针的空否决定该位置是否停有车辆
public:
	Park(int Num){
		spaces=new Automobile*[Num];
		for(int i=0;i<Num;i++)
			spaces[i]=NULL;			//动态分配空间
		
		N=Num;				//停车位初始化
		income=0;			//收入初始化
		numAuto=0;			//停车数量初始化
	}
	~Park() { delete[] spaces; };
	void showInfo();			//显示当前停车场里车辆信息,以及当前全部的停车费收入
	void assignSpace(Automobile *pa);					//分配车位
	void reclaimSpace(Automobile *pa, int fee);			//退出缴纳停车费
};


class Automobile{
string plateNO;
public:
	Automobile(string pla) : plateNO(pla){};
	void enter(Park &park) { park.assignSpace(this); };
	void leave(Park &park){};										//基类的enter,leave函数用于验证同名覆盖机制
	string getPlateNO() { return plateNO; };
};

class Truck:public Automobile{
float load;
public:
	Truck(string Pl, float lo) : Automobile(Pl), load(lo){};
	void enter(Park &park) { park.assignSpace(this); };	
	void leave(Park &park) { park.reclaimSpace(this, 3); }
};

class Bus:public Automobile{
int capacity;
public:
	Bus(string Pl, int cap) : Automobile(Pl),capacity(cap){};
	void leave(Park &park) { park.reclaimSpace(this, 2); }
};

class Car:public Automobile{
string brand;
public:
	Car(string Pl, string bra) : Automobile(Pl), brand(bra){};
	void leave(Park &park) { park.reclaimSpace(this, 1); }
};

void Park::showInfo()
{
	cout << "停车场目前停放了" << numAuto << "辆汽车";
	for (int i = 0; i < N;i++)
	{
		if(spaces[i]!=NULL)
			cout << spaces[i]->getPlateNO()<<','; //输出车辆信息
	}
	cout << "共收入" << income << "元" << endl;
}

void Park::assignSpace(Automobile *pa)
{
	if(N==numAuto){
		cout << "停车场已经满了,无法为" << pa->getPlateNO() << "分配停车位" << endl;
		return ;
	}
	else {
		cout << pa->getPlateNO() << "进入停车场,分配停车位!" << endl;
		//寻找空位
		for (int i = 0; i < N;i++){
			if(spaces[i]==NULL){			//空位
				spaces[i] = pa;
				numAuto++;
				break; 						//跳出循环
			}
		}
	}
};

void Park::reclaimSpace(Automobile *pa, int fee){
	income = income + fee;		//缴纳停车费
	//删除停车位指针
	for (int i = 0; i < N;i++){
		if(pa->getPlateNO()==spaces[i]->getPlateNO()){
			cout << pa->getPlateNO() << "离开停车场，缴纳停车费" << fee << "元" << endl;
			spaces[i] = NULL;
			numAuto--;
			break;
		}
	}
};


int main()
{
	int Num = 0;
	cout << "请输入停车位数量:";
	cin >> Num;				//停车位数量输入
	Park park(Num);			//创建停车场对象
	Truck truck("苏 A-0134", 20);	//创建卡车对象
	truck.enter(park);		//truck进入停车场，分配车位
	Car car1("苏 A-56789", "Audi A8"); //创建轿车对象
	car1.enter(park);		//car1进入停车场，分配停车位
	car1.leave(park);		//car1离开停车场，缴纳停车费
	Bus bus("苏 A-43210",50);	//创建公交车对象
	bus.enter(park);		//bus进入停车场,分配车位
	/*显示当前停放的车辆的车牌号码，以及当前的全部停车费收入*/
	park.showInfo();
	Car car2("苏 A-98765", "Benz S400");	//创建轿车对象
	car2.enter(park);			//car2进入停车场
	//car2进入停车场，分配停车位。因为没有空余停车位，所以无法分配
	bus.leave(park);			//bus离开停车场，缴纳停车费
	truck.leave(park);			//truck离开停车场，缴纳停车位
	/*显示当前停放的车辆的车牌号码，以及当前的全部停车费收入*/
	park.showInfo();
	return 0;
}