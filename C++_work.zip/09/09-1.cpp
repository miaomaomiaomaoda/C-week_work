#include<iostream>
#include<string>
using namespace std;

class GrandFather{
string Name;
int age;
string CardID;
public:
	GrandFather(string a,int b,string c):Name(a),age(b),CardID(c){cout<<"GrandFather构造成功"<<endl;};
	void showName(){cout<<Name<<"  ";};
	void showage(){cout<<age<<"  ";};
	void showCardID(){cout<<CardID<<endl;};
};

class Father:public GrandFather{
string Name;
int age;
string CardID;
public:
	Father(string a,int b,string c,string d,int e,string f)
		:GrandFather(a,b,c),Name(d),age(e),CardID(f)
	{cout<<"Father构造成功"<<endl;};
	void showName(){cout<<Name<<"  ";};
	void showage(){cout<<age<<"  ";};
	void showCardID(){cout<<CardID<<endl;};
};

class Child:public Father{
string Name;
int age;
string CardID;
public:
	Child(string a,int b,string c,  string d,int e,string f,  string g,int h,string i)
		:Father(a,b,c,d,e,f),Name(g),age(h),CardID(i)
	{cout<<"Child构造成功"<<endl;};
//	void showName(){cout<<Name<<"  ";};
	void showage(){cout<<age<<"  ";};
	void showCardID(){cout<<CardID<<endl;};
};

int main(){
	cout<<"***************验证同名覆盖机制和局部优先原则***************"<<endl;
	GrandFather g("GrandFather",70,"123456");
	g.showName();
	g.showage();
	g.showCardID();
	
	Father f("GrandFather",70,"123456","Father",40,"456789");
	f.showName();
	f.showage();
	f.showCardID();

	Child c("GrandFather",70,"123456","Father",40,"456789","Child",10,"789012");
	c.showName();
	c.showage();
	c.showCardID();

	cout<<endl<<"***************验证支配规则(即作用域规则)***************"<<endl;
	f.GrandFather::showName();
	c.GrandFather::showName();
	c.Father::showName();

	cout<<endl<<"*************最近优先原则(需要注释掉Child类中的showName()成员函数)*************"<<endl;
	c.showName();
	cout<<endl;
	return 0;
}