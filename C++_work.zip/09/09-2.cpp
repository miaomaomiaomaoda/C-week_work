#include <iostream>
using namespace std;

//基类Base
class Base{
    int x;
protected:
    int y;
public:
    int z;
    Base(int a,int b,int c):x(a),y(b),z(c){};
    void showxyz() { cout << "Base::x=" << x << "  Base::y=" << y << "  Base::z=" << z << endl; }
};

//子类Derive
class Derive:public Base{
    int dx;
protected:
    int dy;
public:
    int dz;
    Derive(int a, int b, int c, int d, int e, int f) : Base(a, b, c), dx(d), dy(e), dz(f){};
    void showdxyz() { cout << dx << dy << dz; }
};

int main(){
    Base B(1,2,3);
    Derive D(4,5,6,7,8,9);
    cout << "公有派生类对象赋值给基类对象前，基类对象的数据状态如下:" << endl;
    B.showxyz();
    cout << "公有派生类对象赋值给基类对象后，基类对象的数据状态如下:" << endl;
    B = D;
    B.showxyz();
    cout << "公有派生类对象赋值给基类对象引用后，基类对象的数据状态如下:" << endl;
    Base &Ba = D;
    Ba.showxyz();
    cout << "公有派生类对象地址赋值给基类对象指针后，基类对象的数据状态如下:" << endl;
    Base *Bp = &D;
    Bp->showxyz();
    return 0;
}
