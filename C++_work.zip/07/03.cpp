#include<iostream>
#include"path.h"
using namespace std;

int main()
{
	Point pt;
	DI DI1;
	DIclass DIc;
	ExternalDistance(pt);		//友元函数
	DI1.Difunction(pt);			//友元成员
	DIc.DIC(pt);				//友元类
	return 0;
}