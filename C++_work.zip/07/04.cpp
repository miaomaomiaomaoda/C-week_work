#include<iostream>
using namespace std;

//全局变量
int num=0;                          //存放输入学生数
int point=0;                        //插入信息的位置或系统内存放学生数-1

//类
class Course{
    char cno[20];       //课程号
    char cname[20];     //课程名
    public:
        friend class Student;                       //友元类
};

class Score{
    int score;          //分数
    public:                                        
        friend class Student;                       //友元类
};

class Student{
    int sno;            //学号
    char sname[20];     //姓名
    char gender[10];    //性别
    char grade[20];     //班级
    public:
        void student_set(Course&,Score&);           //学籍信息录入
        void student_show(Course,Score);            //学籍信息输出
        int getsno() { return sno; };               //学号获取
};

//Manage类
class Manage{
    public:
        Student st;
        Course co;
        Score sc;
        Manage(){};                 //不带参构造函数
        Manage(char x);             //带参构造函数
        void Manage_show();
};

//带参构造函数
Manage::Manage(char x)
{
    st.student_set(co,sc);
}

//学生学籍信息输入函数
void Student::student_set(Course& co,Score& sc){
    cout << "请输入学生学籍信息:";
    cin >> sno >> sname >> gender >> grade >> co.cno >> co.cname >> sc.score;
}

//学生学籍信息输出函数
void Student::student_show(Course co,Score sc){
    cout <<"查询结果:"<<sno<<"   "<< sname <<"   "<< gender <<"   "<< grade << "   "<<co.cno << "   "<<co.cname <<"   "<< sc.score;
    cout << endl;
}

//输出学籍信息
void Manage::Manage_show()
{
    st.student_show(co, sc);
}
//学生信息输入
void Stu_info_Input(Manage infosystem[200]){
    Manage *p;                          //管理类指针
    cout << "***************学生信息输入***************" << endl;
    while(1){
        cout << "请输入需要输入的学生数:";
        cin >> num;
        cout << "请输入" << num << "个学生的学籍信息:示例（2016116101 张山 男 计科161 COST3114 C++ 90）" << endl;
        for (int i = point; i < point + num;i++)
        {
            p = new Manage('y');
            infosystem[i] = *p;
        }
        point = point + num;                //更新插入位

        //继续输入判断
        char fun;
        cout << "是否需要继续输入学生信息(Y/N):";
        cin >> fun;
        if(fun=='N'||fun=='n')
            break;
    }
    delete p;
}

//表内数据全部输出
void Allout(Manage infosystem[200]){
    cout << "****************全部学生的学籍信息输出****************" << endl;
    if(point==0){
       cout << "学生学籍系统内无学生数据!" << endl;
       return;
    }
    for (int i = 0; i < point; i++)
       infosystem[i].Manage_show();
}

//查询学生信息
void search_info(Manage infosystem[200]){
    cout << "****************学生信息查询****************" << endl;
    while(1){
        int i = 0;
        int point=0;
        int sno;
        cout << "请输入待查询学生的学号：";
        cin >> sno;
        while(infosystem[i].st.getsno())
        {
            if(sno==infosystem[i].st.getsno()){
                point = 1;
                infosystem[i].Manage_show();
                break;
            }
            i++;
        }
        if(point==0)
            cout << "要查询的学生不存在!"<<endl;
        char fun;
        cout << "是否继续查询(Y/N):";
        cin >> fun;
        if(fun=='N'||fun=='n')
            break;
    }
}


//主函数体
int main()
{
    Manage infosystem[200];             //创建信息管理系统类
    char fun;                           //判断标志
    int function;                       //功能选择
    while(1){
        cout << "请输入功能选择(1.学生学籍信息输入 2.输出信息表里全部学生学籍信息 3.查询学生信息)：";
        cin >> function;
        if(function==1)
            Stu_info_Input(infosystem);
        else if(function==2)
            Allout(infosystem);
        else if(function==3)
            search_info(infosystem);
        else
            cout << "输入错误，请重新输入" << endl;
        cout << "是否继续操作（Y/N）:";
        cin >> fun;
        if(fun=='N'||fun=='n')
            break;
    }
    return 0;
}
