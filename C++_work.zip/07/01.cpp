#include<iostream>
using namespace std;

//类
class Box {
	int length;									
	void setwidth() { cin >> width; }
	int height;
public:
	int width;
	void setlength() { cin >> length; }
	friend void getvolumn(Box box);						//友元函数声明
protected:
	void setheight() { cin >> height; }
};

//友元函数定义
void getvolumn(Box box)
{
	cout << "请输入长方体的长宽高:  ";
	box.setlength();
	box.setwidth();
	box.setheight();
	cout <<"长方体的体积为:"<< box.length* box.width* box.height<<endl;
}

//主函数
int main()
{
	char function;
	Box box;
	//循环求体积
	while(1)
	{
		getvolumn(box);
		cout<<"是否继续判断?(Y/N)";
		cin>>function;
		if(function=='N'||function=='n')
			break;
	}
	return 0;
}