//避免重复定义
#ifndef _path_h_
#define _path_h_

#include<iostream>
#include<math.h>
using namespace std;
class Point;            //类引用声明
class DI{
    public:
    void Difunction(Point);
};

class Point{
    int x, y;
    int m, n;
    public:
        Point();
        friend class DIclass;                        //友元类(定义放后面)
        friend void ExternalDistance(Point);         //友元函数声明
        friend void DI::Difunction(Point);           //友元成员（定义一般放在需要表达的类的前面）
};

//友元类定义
class DIclass{
    public:
        void DIC(Point);
};

//构造函数定义
Point::Point()
{
    cout << "请输入两点的坐标(示例：2 5 1 4):";
    cin >> x >> y >> m >> n;
}

//友元函数定义
void ExternalDistance(Point pt)
{
    double distance;
    distance = pow((pt.m - pt.x), 2) + pow((pt.n - pt.y), 2);
    distance = sqrt(distance);
    cout << '(' << pt.x << ',' << pt.y << ")->(" << pt.m << ',' << pt.n << ")的距离为:"<<distance<<endl;
}

//友元成员定义
void DI::Difunction(Point pt)
{
    double distance;
    distance = pow((pt.m - pt.x), 2) + pow((pt.n - pt.y), 2);
    distance = sqrt(distance);
    cout << '(' << pt.x << ',' << pt.y << ")->(" << pt.m << ',' << pt.n << ")的距离为:"<<distance<<endl;
}

//友元类的成员函数
void DIclass::DIC(Point pt)
{
    double distance;
    distance = pow((pt.m - pt.x), 2) + pow((pt.n - pt.y), 2);
    distance = sqrt(distance);
    cout << '(' << pt.x << ',' << pt.y << ")->(" << pt.m << ',' << pt.n << ")的距离为:"<<distance<<endl;
}

#endif