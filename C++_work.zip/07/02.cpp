#include<iostream>
using namespace std;

class Box;                  //声明引用的类名
class Inputdata{
public:
    void Input(Box &);      //成员函数
};

class Box{
    public:
    int length;
    private:
    int width;
    protected:
    int height;
    friend class Output;                            //声明友元类
    friend void Inputdata::Input(Box &);            //声明友元成员
};

//成员类
class Output{
    public:
        void Getvolumn(Box);
};

//友元成员定义
void Inputdata::Input(Box& bx)
{
    cout << "请输入长方体的长宽高：";
    cin >> bx.length >> bx.width >> bx.height;
    cout << "输入的长宽高分别为:"
         << "length=" << bx.length << "   width=" << bx.width << "    height=" << bx.height<<endl;
}

//Output友元类的成员函数定义
void Output::Getvolumn(Box bx)
{
    cout << "长方体的体积为:" << bx.length * bx.width * bx.height << endl;
}

int main()
{
    Box bx;
    Inputdata Inp;
    Output Out;
    char function;
    while(1){
    Inp.Input(bx);
    Out.Getvolumn(bx);
    cout << "是否需要继续求长方体的长宽高?(Y/N)";
    cin >> function;
    if (function == 'N' || function == 'n')
        break;
    }
    return 0;
}

